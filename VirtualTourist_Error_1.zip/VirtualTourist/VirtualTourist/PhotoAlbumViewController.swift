//
//  PhotoAlbumViewController.swift
//  VirtualTourist
//
//  Created by Saad altwaim on 9/8/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class PhotoAlbumViewController: UIViewController , MKMapViewDelegate , UICollectionViewDelegate , UICollectionViewDataSource 
{
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var collectionViewButton: UIButton!
    
    var dataController : DataController?
    var pin : Pin?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        createNavButton(title: "OK", imageName: "Button2.png")
        
        createCellLayout(numberOfItemsPreRow : 3.0 , leftAndRightPaddings : 32.0 ,heightAdjustment : 32.0)
        
        //checkForExistingPhotoInCoreData()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        
        resetCollectionView()
    }
    
    func createNavButton(title: String , imageName : String) // Page 11 Note 3 
    {
        let backbutton = UIButton(type: .custom)
        backbutton.setImage(UIImage(named: imageName), for: .normal)
        backbutton.setTitle(title, for: .normal)
        backbutton.setTitleColor(backbutton.tintColor, for: .normal)
        backbutton.addTarget(self, action: #selector(self.backButton), for: .touchUpInside)

        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backbutton)
        
        showSelectedPin()
    }

    @objc func backButton()
    {
        navigationController?.popViewController(animated: true)
    }
    
    func showSelectedPin()
    {
        let lat = FlickrApiClient.LocationVariable.latitude
        let lon = FlickrApiClient.LocationVariable.longitude
        
        let annotation = MKPointAnnotation()
        let location = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        annotation.coordinate = location
        let span = MKCoordinateSpan(latitudeDelta: 1.3, longitudeDelta: 1.3)
        let region = MKCoordinateRegion(center: annotation.coordinate, span: span)
        
        mapView.setRegion(region, animated: true)
        mapView.addAnnotation(annotation)
        
        displayFlickrApiPhoto()
    }

    func displayFlickrApiPhoto()
    {
        FlickrApiClient.getFlickrPhotosSearchForLocation
        {
            (flickrPhoto , error) in
            print("message from view contrller" , flickrPhoto)
            
            FlickerDataModel.dataList = flickrPhoto
             
            if (FlickerDataModel.dataList == [] || error != nil)
            {
                DispatchQueue.main.async
                {
                    let alertVC = UIAlertController(title: "Error", message: "No Image was found in this Location", preferredStyle: .alert)
                    let alertButton = UIAlertAction(title: "OK", style: .default,
                                                    handler: { (action) -> Void in
                                                    self.navigationController?.popViewController(animated: true)})
                    alertVC.addAction(alertButton)
                    self.present(alertVC,animated: true, completion: nil)
                }
            }
                
            else
            {
                print("NO Error in PhotoAlbumViewController")
                print("FlickerDataModel",FlickerDataModel.dataList.count)
                
                DispatchQueue.main.async
                {
                    self.collectionView.reloadData()
                }
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        guard annotation is MKPointAnnotation else { print("no mkpointannotaions"); return nil }
        
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if (pinView == nil)
        {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.image = UIImage(named: "mapPin1")
        }
        else
        {
            pinView!.annotation = annotation
        }
        return pinView
    }
    
    func resetCollectionView()
    {
        FlickerDataModel.dataList = []
        collectionView.reloadData()
    }
 
    func checkForExistingPhotoInCoreData()
    {
        let fetchRequest : NSFetchRequest<Photo> = Photo.fetchRequest()
        let predicate = NSPredicate(format: "pin == %@", pin!)
        
        fetchRequest.predicate = predicate
        
        if let resulte = try? dataController?.viewContext.fetch(fetchRequest)
        {
            for loadCoreData in resulte as [NSManagedObject]
            {
                let loadData = loadCoreData.value(forKey: "locationPhotos") as! Data
                print("predicate count",loadData.count)
                //CoreDataLoadingDataModel.dataList = [UIImage(data: loadData)!]
                //print("predicate",CoreDataLoadingDataModel.dataList.count)
            }
        }
        else
        {
            print(Error.self)
            print("Error The Value is NOT in predicate")
        }
    }
    
    func saveImagesToCoredata(iamgeUrl : URL)
    {
        if let imageData = try? Data(contentsOf: iamgeUrl)
        {
            if let image = UIImage(data: imageData)
            {
                let pngImageData = image.pngData()
                let photo = Photo(context: self.dataController!.viewContext)
                photo.locationPhotos = pngImageData
                photo.pin = self.pin // Note D Page 15
                
                do
                {
                    try self.dataController?.viewContext.save()
                    print("The image was save in core COREDATA")
                }
                catch
                {
                    print(error.localizedDescription)
                    print(error)
                    print("Cant save IMAGE TO COREDATA")
                }
            }
        }
    }
    
    // MARK: - collectionView
    
    @IBAction func newCollectionButton(_ sender: Any)
    {
        displayFlickrApiPhoto()
    }
    
    func createCellLayout(numberOfItemsPreRow : CGFloat , leftAndRightPaddings : CGFloat ,heightAdjustment :  CGFloat) // Page 11 Note 4
    {
        let width  = (collectionView!.frame.width - leftAndRightPaddings) / numberOfItemsPreRow
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: width, height: width + heightAdjustment)
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return FlickerDataModel.dataList.count
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        FlickerDataModel.dataList.remove(at: indexPath.item)
        self.collectionView.deleteItems(at: [indexPath])
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        // Page 13 note 1 
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FlickrCollectionViewCell", for: indexPath) as! CollectionViewCell
        
        let DataModel = FlickerDataModel.dataList[indexPath.row]
        
        //cell.imageView.image = UIImage(named: "placeholder1")
        
        let urlString = "https://live.staticflickr.com/\(DataModel.server)/\(DataModel.id)_\(DataModel.secret)_m.jpg"
        print("The Flicker URL IS :  ",urlString)
        
        let imageUrl = URL(string: urlString)
        
        saveImagesToCoredata(iamgeUrl: imageUrl!)

        let disabledButton = collectionViewButton
        cell.imageView.loadImage(fromURL: imageUrl!, placeHolderImage : "placeholder1", button: disabledButton!) // old cell Code Page 13 - 1
        
        collectionViewButton.isEnabled = false
        return cell
    }
}

/*

// old cell Code Page 13 - 2
 
 cell.imageView.image = UIImage(named: "placeholder1")
 DispatchQueue.global(qos: .utility).async
 {
     [weak self] () -> Void in
     let urlString = "https://live.staticflickr.com/\(DataModel.server)/\(DataModel.id)_\(DataModel.secret)_t.jpg"
     print("The Flicker URL IS :  ",urlString)
     
     let data = try? Data(contentsOf: URL(string: urlString)!)
     guard self != nil else { return }
     
     DispatchQueue.main.async
     {
         () -> Void in
         let image = UIImage(data: data!)
         cell.imageView.image = image
     }
 }
 */

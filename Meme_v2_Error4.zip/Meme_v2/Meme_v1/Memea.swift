//
//  Meme.swift
//  Meme_v1
//
//  Created by Saad altwaim on 6/28/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import Foundation
import UIKit

 struct Meme
{
    let topTxt: String
    let btmTxt: String
    let display:UIImage!
    let memedImage:UIImage!
}


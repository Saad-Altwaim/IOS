//
//  memeDetailView.swift
//  Meme_v1
//
//  Created by Saad altwaim on 7/15/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import UIKit

class memeDetailView: UIViewController {
            
       var memes: [ViewController.Meme]! {
       let object = UIApplication.shared.delegate
       let appDelegate = object as! AppDelegate
       return appDelegate.memes
    }
    
    var detail:ViewController.Meme?
    
    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imageView?.image = detail!.memedImage!
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

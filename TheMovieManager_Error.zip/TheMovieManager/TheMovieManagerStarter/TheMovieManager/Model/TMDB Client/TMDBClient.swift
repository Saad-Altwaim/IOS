//
//  TMDBClient.swift
//  TheMovieManager
//
//  Created by Owen LaRosa on 8/13/18.
//  Copyright © 2018 Udacity. All rights reserved.
//

import Foundation

class TMDBClient {
    
    static let apiKey = "84d45e0f24fd173cc2cb691e8569b1ad"
    
    struct Auth {
        static var accountId = 0
       // static var accountId = 9574286
        static var requestToken = ""
        static var sessionId = ""
    }
    
    enum points {
        static let base = "https://api.themoviedb.org/3"
        static let apiKeyParam = "?api_key=\(TMDBClient.apiKey)"
        
        case getWatchlist
        case getRequestToken // (https://developers.themoviedb.org/3/authentication/create-request-token )
        case login           // (https://developers.themoviedb.org/3/authentication/validate-request-token)
        case createSeesionId // (https://developers.themoviedb.org/3/authentication/create-session)
        case webAuth         // (https://developers.themoviedb.org/3/authentication/how-do-i-generate-a-session-id)
        // webAuth  login using web brower // [13] page 163 -5
        
        case logou           // (https://developers.themoviedb.org/3/authentication/delete-session)  //[14] page 164 - 1
        case getFavorites    //(https://developers.themoviedb.org/3/account/get-favorite-movies) //NOTE 1  page 167
        case search(String)  //(https://developers.themoviedb.org/3/search/search-movies) Note A page 168
        case markWatclist    //(https://developers.themoviedb.org/3/account/add-to-watchlist)
        
        
        var stringValue: String
        {
            switch self
            {
                case .getWatchlist: return points.base + "/account/\(Auth.accountId)/watchlist/movies" + points.apiKeyParam + "&session_id=\(Auth.sessionId)"
                case .getRequestToken:
                    return points.base + "/authentication/token/new" + points.apiKeyParam
                case .login:
                    return points.base + "/authentication/token/validate_with_login" + points.apiKeyParam
                case.createSeesionId:
                    return points.base + "/authentication/session/new" + points.apiKeyParam
                case.webAuth:
                    return "https://www.themoviedb.org/authenticate/" + Auth.requestToken + "?redirect_to=themoviemanager:authenticate" // [13] page 163 -6
                case .logou:
                    return points.base + "/authentication/session" + points.apiKeyParam
                case .getFavorites:
                    return points.base + "/account/\(Auth.accountId)/favorite/movies" + points.apiKeyParam +
                    "&session_id=\(Auth.sessionId)"
                case .search(let query): // Note A
                    return points.base + "/search/movie" + points.apiKeyParam + "&query=\(query.addingPercentEncoding(withAllowedCharacters:.urlQueryAllowed) ?? "")" // Note A
                // Note D  query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed  Page 169
                case.markWatclist :
                    return points.base + "/account/\(Auth.accountId)/watchlist" + points.apiKeyParam + "&session_id=\(Auth.sessionId)"
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }

    
    // the Refactor Code start here  - for GET
    class func taskForGETRequest<ResponseType: Decodable>
    //the 1 parametr         2 parametr                                3 parametr   NOTE 1 Page 165
    (url: URL, responseType: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void)
    {                         // note3 page 166                         // note3 page 166
        let task = URLSession.shared.dataTask(with: url)
        {
            data, response, error in
            guard let data = data
            else
            {
                DispatchQueue.main.async //note 5 Page 166
                {
                    completion(nil, error)
                }
                
                return
            }
            let decoder = JSONDecoder()
            
            do
            {
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.async //note 5 Page 166
                {
                    completion(responseObject, nil) // NOTE 1 Page 165
                }
               // print("the value for completion IN taskForGETRequest do",responseObject)
            }
            catch
            {
                DispatchQueue.main.async //note 5 Page 166
                {
                    completion(nil, error)
                }
            }
        }
        task.resume()
    }
    
    
    class func getWatchlist(completion: @escaping ([Movie], Error?) -> Void)
    {                                                               // note3 page 166
        taskForGETRequest(url: points.getWatchlist.url,responseType: MovieResults.self)
        {
            (response, Error) in
            if let response = response // note3 page 166  , // note4 page 166
            {
                completion(response.results,nil) // Note2 page 166
                // the completion is for getWatchlist // note4 page 166
            }
            else
            {
                completion([],Error) // the completion is for getWatchlist // note4 page 166
            }
        }
    }
    
    class func getRequestToken(completion: @escaping (Bool , Error?) -> Void)
    {
        taskForGETRequest(url: points.getRequestToken.url, responseType: theRequestTokenResponse.self)
        {
            (response, Error) in
            if let response = response
            {
                Auth.requestToken = response.request_token // Like th do block in the OLD function
                completion(true,nil) // Note2 page 166  // the completion is for getRequestToken
            }
            else
            {
                completion(false,Error)
            }
        }
    }
    /* -1
     // a Working Method but we need to Refactor this Method
     //the Refactor Code start from the taskForGETRequest Method
     //to use this method disable taskForGETRequest
     
     chapter 7 [11]
     // the new one is  taskForGETRequest [3] [4] Page 165
     
    class func getWatchlist(completion: @escaping ([Movie], Error?) -> Void) {
        let task = URLSession.shared.dataTask(with: points.getWatchlist.url) { data, response, error in
            guard let data = data else {
                completion([], error)
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(MovieResults.self, from: data)
                completion(responseObject.results, nil) // NOTE 1 Page 165
            } catch {
                completion([], error)
            }
        }
        task.resume()
    }
     
  -1  */
    
    
    /* -2
     
     // a Working Method but we need to Refactor this Method
     //the Refactor Code start from the taskForGETRequest Method
     //to use this method disable taskForGETRequest
     
     
     chapter 7 [11]
     // the new one is  taskForGETRequest  [3] [4] Page 165
     
    // My FUNCTION
    // the first step is to Create Token [7] Page 158
    class func getRequestToken(completion: @escaping (Bool , Error?) -> Void)
    {
        let task = URLSession.shared.dataTask(with: points.getRequestToken.url)
        {
            data, response, error in
            guard let data = data
            else
            {
                completion(false,error)
                print("URL",points.base + "/authentication/token/new" + points.apiKeyParam)
                print("Error IN the getRequestToken Function ")
                return
            }
            let decoder = JSONDecoder()
            
            do
            {
                let responseToken = try decoder.decode(theRequestTokenResponse.self, from: data)
                print(responseToken)
                Auth.requestToken = responseToken.request_token // struct RequestTokenResponse
                //completion(responseToken.success,error)  NOTE 1 Page 165
                completion(true,nil)
            }
            catch
            {
                print("URL",points.base + "/authentication/token/new" + points.apiKeyParam)
                print("Error IN the catch getRequestToken Function ")
                completion(false,error)
            }
        }
        task.resume()
    }
    
 -2 */


    // the Refactor Code start here for the POS
    class func taskForPOSTRequest<RequestType: Encodable,
    ResponseType: Decodable>(url: URL, responseType: ResponseType.Type,
    body: RequestType, completion: @escaping (ResponseType?, Error?) -> Void)
    {
        var request = URLRequest(url: url) // -1  [A -var request ]
        request.httpMethod = "POST" // -2
        request.addValue("application/json", forHTTPHeaderField: "Content-Type") // -3
        let requestBody = body// -5 //
        request.httpBody = try! JSONEncoder().encode(requestBody) //
        //request.httpBody = try! JSONEncoder().encode(Body) // IN The tutorials [5]
        let task = URLSession.shared.dataTask(with: request)  // -6
        {
            (Data, URLResponse, Error) in
            guard let data = Data
            else
            {
                DispatchQueue.main.async //note 5 Page 166
                {
                    completion(nil,Error)
                }
                print("Error IN the loging Function ")
                return
            }
            
            do // -7
            {
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.async //note 5 Page 166
                {
                    completion(responseObject,nil)
                }
            }
            catch
            {
                print("Error IN the catch loging Function ")
                DispatchQueue.main.async //note 5 Page 166
                {
                    completion(nil,error)
                }
            }
        }
        task.resume()
    }

    class func loging(userName : String , passWord : String , completion: @escaping (Bool , Error?) -> Void)
    {
        //let body = LoginRequest    //  THE STRUCT IN The tutorials [5]
        taskForPOSTRequest(url: points.login.url,
        responseType: theRequestTokenResponse.self,
        // body : body //  THE STRUCT IN The tutorials [5]
        body: LoginRequest(username: userName, password: passWord, requestToken: Auth.requestToken))
        {
            (response, Error) in
            if let response = response
            {
                Auth.requestToken = response.request_token
                completion(true,nil)
            }
            else
            {
                completion(false,Error)
            }
        }
        
    }
    
    class func createSessionID(completion : @escaping (Bool , Error?)-> Void)
    {
        taskForPOSTRequest(url: points.createSeesionId.url,
        responseType: SessionRespons.self,
        body: PosSession(requestToken: Auth.requestToken))
               {
                   (response, Error) in
                   if let response = response
                   {
                       Auth.sessionId = response.session_id
                       completion(true,nil)
                   }
                   else
                   {
                       completion(false,Error)
                   }
               }
    }
    
    class func getFavorites(completion : @escaping ([Movie] , Error?) ->Void)
    {
        taskForGETRequest(url: points.getFavorites.url,responseType: MovieResults.self)
        {
            (response, Error) in
            if let response = response // note3 page 166  , // note4 page 166
            {
                completion(response.results,nil) // Note2 page 166
                // the completion is for getFavorites // note4 page 166
            }
            else
            {
                completion([],Error) // the completion is for getWatchlist // note4 page 166
            }
        }
    }
    
    /* -3
     
    // a Working Method but we need to Refactor this Method
    //the Refactor Code start from the taskForPOSRequest Method
    // to use this method disable taskForPOSRequest
     
     
    // Note page 161
    // the the Secon step is to make the Token Authorized
    // using the userName , password ,Token
    // [9] Page 160 - 161
    
    
    class func loging(userName : String , passWord : String , completion: @escaping (Bool , Error?) -> Void)
    {
        var request = URLRequest(url: points.login.url) // -1  [A -var request ]
        request.httpMethod = "POST" // -2
        request.addValue("application/json", forHTTPHeaderField: "Content-Type") // -3
        let body = LoginRequest(username: userName, password: passWord, requestToken: Auth.requestToken) // -4
        request.httpBody = try! JSONEncoder().encode(body) // -5
        
        let task = URLSession.shared.dataTask(with: request)  // -6
        {
            (Data, URLResponse, Error) in
            guard let data = Data
            else
            {
                completion(false,Error)
                print("Error IN the loging Function ")
                return
            }
            
            do // -7
            {
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(theRequestTokenResponse.self, from: data)
                Auth.requestToken = responseObject.request_token
                completion(true,nil)
            }
            catch
            {
                print(LoginRequest(username: userName, password: passWord, requestToken: Auth.requestToken))
                print("Error IN the catch loging Function ")
                completion(false,error)
                print("the completion valus IS : ",completion(false,error))
            }
        }
        task.resume()
        
    }
    
    -3 */
    
    
    /* -4
    
    // a Working Method but we need to Refactor this Method
    //the Refactor Code start from the taskForPOSRequest Method
    // to use this method disable taskForPOSRequest
    
    
    // the Third step is to create session ID with the userName & Authorized Token
    //[10] Page 161 - 162 
    class func createSessionID(completion : @escaping (Bool , Error?)-> Void)
    {
        var request = URLRequest(url: points.createSeesionId.url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let body = PosSession(requestToken: Auth.requestToken)
        request.httpBody = try! JSONEncoder().encode(body)
        
        let task = URLSession.shared.dataTask(with: request)
        {
            (Data, URLResponse, Error) in
            guard let data = Data
            else
            {
                completion(false,Error)
                print("Error IN the createSessionID Function")
                return
            }
            
            do
            {
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(SessionRespons.self, from: data)
                Auth.sessionId = responseObject.session_id
                completion(true,nil)
            }
            catch
            {
                print("Error IN the catch createSessionID Function ")
                completion(false,error)
                
            }
        }
        task.resume()
    }
    
    -4 */
    
    class func logouSessionID(completion : @escaping ()-> Void) //[14] page 164 - 2
    {
        var request = URLRequest(url: points.logou.url)
        request.httpMethod = "DELETE" //[14] page 164 - 3
        let body = Logout(sessionID: Auth.sessionId) //[14] page 164 - 4  [ the struct IN Logout.swift ]
        request.httpBody = try! JSONEncoder().encode(body)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let task = URLSession.shared.dataTask(with: request) //[14] page 164 - 5
        {
            (Data, URLResponse, Error) in
            Auth.requestToken = "" //[14] page 164 - 6
            Auth.sessionId = "" //[14] page 164 - 6
            completion() //[14] page 164 - 7
            
            // the function IN //  UIViewController+Extension.swift
        }
        task.resume()
    }
    /*
     
     // a Working Method but we need to Refactor this Method
     // the Refactor Code start from the taskForPOSRequest Method
     // to use this method disable taskForPOSRequest
     note page 167 - 168
     
     
    class func getFavorites(completion : @escaping ([Movie] , Error?) ->Void)
    {
        let task = URLSession.shared.dataTask(with:points.getFavorites.url )
        {
            (Data, URLResponse, Error) in
            guard let data = Data
            else
            {
                completion([],Error)
                return
            }
            let dcoder = JSONDecoder()
            do
            {
                
                let responseObject = try dcoder.decode(MovieResults.self, from: data)
                completion(responseObject.results,Error) //note2 page 167
            }
            catch
            {
                completion([],Error)
                print("Error IN the getFavorites catch")
            }
        }
        task.resume()
    }
    */
    
                                                               // Note B page 168
    class func search (query : String , completion : @escaping ([Movie],Error?)->Void)
    {
        taskForGETRequest(url: points.search(query).url, responseType: MovieResults.self)
        {
            (response, Error) in
            if let response = response
            {
                completion(response.results,nil)
            }
            else
            {
                completion([],Error)
            }
            
        }
    }
    // statusCode (https://www.themoviedb.org/documentation/api/status-codes)
    //Page 169 [9]
    class func markWatchlist (movie_id : Int , watch_list :Bool,completion : @escaping (Bool ,Error?)->Void)
    {
        taskForPOSTRequest(url:points.markWatclist.url,
        responseType: TMDBResponse.self, body:MarkWatchlist(mediaType:"movie",
        medaiID: movie_id, watchlist: watch_list))
        {
            (response, Error) in
            if let response = response
            {
                completion(response.statusCode == 1
                        || response.statusCode == 12
                        || response.statusCode == 13 , nil)
                print(" markWatchlist response IS OK  ")
                print(" the statusCode = ",response.statusCode)
                print("requestToken = ",Auth.requestToken)
                print("accountId = ",Auth.accountId)
                print("sessionId = ",Auth.sessionId)
                print("The Link")
                print(points.base + "/account/\(Auth.accountId)/watchlist" + points.apiKeyParam + "&session_id=\(Auth.sessionId)")
                
            }
            else
            {
                completion(false,Error)
                print(" markWatchlist response IS Error  ")
            }
        }
    }
    
}


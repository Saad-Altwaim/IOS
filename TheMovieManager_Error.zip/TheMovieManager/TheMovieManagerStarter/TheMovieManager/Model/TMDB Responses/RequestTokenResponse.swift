//
//  RequestTokenResponse.swift
//  TheMovieManager
//
//  Created by Owen LaRosa on 8/13/18.
//  Copyright © 2018 Udacity. All rights reserved.
//

import Foundation

struct theRequestTokenResponse : Codable
{
    var success : Bool
    var exData_at : String
    var request_token : String
    
    enum CodingKeys: String, CodingKey
    {
        case success = "success"
        case exData_at = "expires_at"
        case request_token = "request_token"
        
    }
}

//
//  LoginViewController.swift
//  TheMovieManager
//
//  Created by Owen LaRosa on 8/13/18.
//  Copyright © 2018 Udacity. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var loginViaWebsiteButton: UIButton!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        emailTextField.text = ""
        passwordTextField.text = ""
    }

    // NOTE 1 page 162
    //the frist function
    //My function                 //(suceess) IN tutorial
    func handleRequestTokenResonse(requestTokenValue : Bool, Error :Error?)// A helper Method
    {
        print("the value for the Token IS :" ,requestTokenValue)
        //print("[handleRequestTokenResonse]The value for Auth struct IS",TMDBClient.Auth.requestToken)
        //if suceess (IN tutorial)
        if requestTokenValue // == if suceess
        {
            print("[handleRequestTokenResonse]The value for Auth struct IS",TMDBClient.Auth.requestToken)
            //DispatchQueue.main.async  //chapter 7 [11]  i Disable DispatchQueue becuese we use A Refactor
            // if We disable the taskForGETRequest Method we can use the DispatchQueue.main.async
           // {
                TMDBClient.loging(userName: self.emailTextField.text ?? "" , passWord: self.passwordTextField.text ?? "",
                completion: self.handleLoginResponse(suceess:Error:))
           // }
        }
    }
    
    // NOTE 1 page 162
    // the 2 call
    func handleLoginResponse(suceess : Bool , Error :Error?)
    {
        print("[handleLoginResponse]The value for Auth struct IS",TMDBClient.Auth.requestToken)
        if suceess == true
        {
            TMDBClient.createSessionID(completion: self.handelSessionResponse(requestSessionValue:Error:))
            
        }
    }
    // the third call page 162
    func handelSessionResponse(requestSessionValue : Bool , Error :Error?)
    {
        if requestSessionValue == true
        {
            //DispatchQueue.main.async // if We disable the taskForGETRequest Method we can use the DispatchQueue.main.async
           // {
                print("the Login is good ")
                self.performSegue(withIdentifier: "completeLogin", sender: nil)
           // }
            
        }
    }
    
    @IBAction func loginTapped(_ sender: UIButton)
    {
        // NOTE 1 page 162 
        //the frist call
        TMDBClient.getRequestToken(completion: handleRequestTokenResonse(requestTokenValue:Error:))
        performSegue(withIdentifier: "completeLogin", sender: nil)
    }
    
    @IBAction func loginViaWebsiteTapped() // -1 Page 163
    {
       // performSegue(withIdentifier: "completeLogin", sender: nil)
        TMDBClient.getRequestToken //NOTE 2 Page 162  // -2
        {
            (suceessToken, Error) in
            if suceessToken == true //- 3
            {
                //DispatchQueue.main.async   //chapter 7 [11]  i Disable DispatchQueue becuese we use A Refactor
                //{
                
                    // this mothod is to open URL from the App
                    UIApplication.shared.open(TMDBClient.points.webAuth.url, options: [:], completionHandler: nil) // -4 
                //}
            }
        }
    }
}

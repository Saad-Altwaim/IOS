//
//  MovieDetailViewController.swift
//  TheMovieManager
//
//  Created by Owen LaRosa on 8/13/18.
//  Copyright © 2018 Udacity. All rights reserved.
//

import UIKit

class MovieDetailViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var watchlistBarButtonItem: UIBarButtonItem!
    @IBOutlet weak var favoriteBarButtonItem: UIBarButtonItem!
    
    var movie: Movie!// THE MOVIE STRUCT
    
    // true if thw movie is IN the watch List
    // false is the movie is not in the watch List
    // page 171
    var isWatchlist: Bool {
        print("THE VALUE FOR isWatchlist IS  : ",MovieModel.watchlist.contains(movie))
        return MovieModel.watchlist.contains(movie)
        
    }
    
    var isFavorite: Bool {
        return MovieModel.favorites.contains(movie)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = movie.title
        
        toggleBarButton(watchlistBarButtonItem, enabled: isWatchlist)
        toggleBarButton(favoriteBarButtonItem, enabled: isFavorite)
        print("1 - THE VALUE FOR ! isWatchlist IS : ",!isWatchlist)
        print("2 - THE VALUE FOR  isWatchlist IS : ",isWatchlist)
        
    }
    
    @IBAction func watchlistButtonTapped(_ sender: UIBarButtonItem)
    {
        TMDBClient.markWatchlist(movie_id:movie.id,
                                 watch_list:!isWatchlist,
                completion:handelWatchListRespons(success:error:))
        print("the Movie Name is : ",movie.title)
    }
    //Page 169 [9]
    func handelWatchListRespons(success : Bool,error :Error?)
    {
        print("message from handelWatchListRespons & success IS : ",success)
        if success// ckock if the response is success OR not(if there Data Comes from the API server)
        {
            if isWatchlist//Note 1 page 172 
            {
                MovieModel.watchlist = MovieModel.watchlist.filter(){$0 != self.movie}
                print("the movie is -")
            }
            else
            {
                MovieModel.watchlist.append(movie)
                print("the movie is +")
            }
            toggleBarButton(watchlistBarButtonItem, enabled:isWatchlist)
        }
    }
    
    @IBAction func favoriteButtonTapped(_ sender: UIBarButtonItem) {

    }
    
    func toggleBarButton(_ button: UIBarButtonItem, enabled: Bool) {
        if enabled {
            button.tintColor = UIColor.primaryDark
        } else {
            button.tintColor = UIColor.gray
        }
    }
    
    
}

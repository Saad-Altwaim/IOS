//
//  udacityApiClient.swift
//  onTheMap
//
//  Created by Saad altwaim on 10/25/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import Foundation

class udacityApiClient
{
    enum points
    {
        static let baseUrl = "https://onthemap-api.udacity.com/v1"
        
        case login
        case studentNames(Int)
        var urlValue: String
        {
            switch self
            {
                case .login:
                    return points.baseUrl + "/session"
                case .studentNames(let limit):
                    return points.baseUrl + "/StudentLocation?limit=\(limit)"
            
            }
        }
        
        var url :URL
        {
            return URL(string: urlValue)!
        }
    }
    class func stLoc()
    {
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation?limit=8")!)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
          if error != nil { // Handle error...
              return
          }
          print(String(data: data!, encoding: .utf8)!)
        }
        task.resume()
    }
    
    class func login(userName:String , passWord:String,completion: @escaping(Bool , Error?) -> Void)
    {
        var request = URLRequest(url: points.login.url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let requestBody = LoginRequest(username: userName, password: passWord)
        let body = udacityApiRequest(udacity: ["username" : requestBody.username,"password" : requestBody.password])
        request.httpBody = try! JSONEncoder().encode(body)
        let task = URLSession.shared.dataTask(with: request)
        {
            (Data,URLResponse,Error) in
            guard let data = Data
            else
            {
                completion(false,Error)
                print("Error IN the login Function ")
                return
            }
            do
            {
                let range = 5..<data.count
                let newData = data.subdata(in: range) /* subset response data! */
                print(String(data: newData, encoding: .utf8)!)
                
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(loginResponse.self, from: newData)
                print("THE RESPONSE :",responseObject)
                let authUser = responseObject.account.registered
                print("THE VALUE OF THE KEY IS : ",authUser)
                completion(authUser,nil)

            }
            catch
            {
                do
                {
                    let range = 5..<data.count
                    let newData = data.subdata(in: range) /* subset response data! */
                    print(String(data: newData, encoding: .utf8)!)
                    
                    let decoder = JSONDecoder()
                    let statusObject = try decoder.decode(StatusResopnse.self,from: newData) as Error //Note 1 Page 191
                    print(statusObject)
                    print("Message from the do in father catch ")
                    completion(false,statusObject)
                }
                catch
                {
                    print("Error IN the child catch from loging Function ")
                    completion(false,error)
                }

            }
        }
        task.resume()
        
    }
    
    class func studentNames(completion : @escaping (Bool , Error?)-> Void)
       //class func studentNames(userName:String )
    {        
        let task = URLSession.shared.dataTask(with: points.studentNames(5).url)
        {
            data,response,error in
            guard let Data = data
            else
            {
                completion(false,error)
                //print("the studentNames URL",points.studentNames(10).url)
                print("Error IN studentNames Function ")
                return
            }
            do
            {
                print("the studentNames URL",points.studentNames(5).url)
                print("Raw JSON Data /n",String(data: Data, encoding: .utf8)!)
                let decoder = JSONDecoder()
                let resultsObject = try decoder.decode(ResultsResponse.self, from: Data)
                print("The ResultsResponse STRUCT : ",resultsObject)
                completion(true,error)
            }
            catch
            {
                print(error.localizedDescription)
                print("Error IN the catch from studentNames ")
                
                completion(false,error)
            }

        }
        task.resume()
    }
    
}

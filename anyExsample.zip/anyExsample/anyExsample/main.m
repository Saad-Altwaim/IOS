//
//  main.m
//  anyExsample
//
//  Created by Saad altwaim on 3/23/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>
// #import "anyExsample-Bridging-Header.h"
#import "anyExsample-Swift.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool
    {
        NSLog(@"Hello, World!");
        theKey * aKeyClass = [[theKey alloc]init];
        [aKeyClass usingKeys];

    }
    return 0;
}

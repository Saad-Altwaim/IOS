//
//  NSObject+Backpack1.h
//  anyExsample
//
//  Created by Saad altwaim on 3/23/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <AppKit/AppKit.h>


#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Backpack1 : NSObject
@property (nonatomic) NSMutableArray * Keye;
-(instancetype)init;
@end

NS_ASSUME_NONNULL_END

//
//  NSObject+Backpack1.m
//  anyExsample
//
//  Created by Saad altwaim on 3/23/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import "NSObject+Backpack1.h"

#import <AppKit/AppKit.h>
@implementation Backpack
-(instancetype)init
{
    self = [super init];
    if(self)
    {
        self.Keys = [[NSMutableArray alloc]init];
        NSString * apiKey = @"bkayZOMvuy8azOhIgxq94k90e7y70hw55";
        [self.Keys addObject:apiKey];
    }
    return self;
}

@end

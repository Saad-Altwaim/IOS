//
//  Main.swift
//  anyExsample
//
//  Created by Saad altwaim on 3/23/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

import Foundation
let backpack = Backpack1()
let houseKey = Key()

backpack.keye.add(houseKey)

let key = backpack.keye[0]
Key.openBoor()

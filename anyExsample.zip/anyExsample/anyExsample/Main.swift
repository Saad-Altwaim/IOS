//
//  Main.swift
//  anyExsample
//
//  Created by Saad altwaim on 3/23/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

import Foundation
@objc class theKey:NSObject
{
  @objc func usingKeys()
  {
        let backpack = Backpack()
        let houseKey = Key()
        backpack.keys.add(houseKey)
        let Key = backpack.keys[1]
        if let key = Key as? Key
        {
            key.openBoor() // this is the  if let key
            print("Home again , home jiggety jig")
        }
        else
        {
            print("let me in ")
        }
        
    }
}


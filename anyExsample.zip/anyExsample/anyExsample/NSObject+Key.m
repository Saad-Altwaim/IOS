//
//  NSObject+Key.m
//  anyExsample
//
//  Created by Saad altwaim on 3/23/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import "NSObject+Key.h"

#import <AppKit/AppKit.h>


@implementation Key

@end

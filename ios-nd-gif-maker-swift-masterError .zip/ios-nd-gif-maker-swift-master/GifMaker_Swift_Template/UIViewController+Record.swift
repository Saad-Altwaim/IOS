//
//  UIViewController+Record.swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 1/10/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
// (https://pinkstone.co.uk/how-to-record-video-files-in-your-ios-app)
// ( https://apple.stackexchange.com/questions/358724/if-we-dont-add-nsphotolibraryaddusagedescription-for-saving-images-to-photo-lib )

import Foundation
import UIKit
import MobileCoreServices // Note 1 Page 47

let frameCount = 16
let delayTime : Float = 0.2
let loopCount = 4 // Means Loop For Ever
let frameRate = 15

extension UIViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    public func launchVideoCamer() // Old Name   @IBAction func launchVideoCamer()
    {
        let recordVideoController = UIImagePickerController()
        recordVideoController.sourceType = UIImagePickerController.SourceType.camera
        recordVideoController.mediaTypes = [kUTTypeMovie as String] // (kUTTypeImage)Note2 Page 47
        recordVideoController.allowsEditing = true //false // trimm Steps - 1 | Note3 Page 47
        recordVideoController.delegate = self
        
        present(recordVideoController,animated : true , completion : nil) // Note1 Page 48
        
    }

     //(https://medium.com/@tjcarney89/accessing-camera-and-photo-library-in-swift-3-b3f075ba1702) this link explain this code
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info:[UIImagePickerController.InfoKey : Any]) // Note2 Page 48 | Note1 Page 54
    {
        let mediaTypes = info[UIImagePickerController.InfoKey.mediaType] as! String
         
         if mediaTypes == kUTTypeMovie as String
         {
            let videoURL = info[UIImagePickerController.InfoKey.mediaURL] as! URL
            //UISaveVideoAtPathToSavedPhotosAlbum(videoURL.path , nil ,nil ,nil)
            dismiss(animated: true ,completion:nil)
            
             // convertVideoToGif(videoURL: videoURL) OLD
            
            let videoLINK = info[UIImagePickerController.InfoKey.mediaURL] as! URL
            print("The videoLINK IS : ",videoLINK)
            
            let start = info[UIImagePickerController.InfoKey.init(rawValue: "_UIImagePickerControllerVideoEditingStart")] as? NSNumber
            let complete = info[UIImagePickerController.InfoKey.init(rawValue: "_UIImagePickerControllerVideoEditingcomplete")] as? NSNumber
            
            
            let duration : NSNumber = NSNumber(value: complete!.floatValue - start!.floatValue)
            
            convertVideoToGif(videoURL: videoURL, start: start, duration: duration)
            
            
            
        }
    }
    
    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) // for the Cancel Button
    {
        dismiss(animated: true ,completion:nil)
    }
    
    func convertVideoToGif(videoURL : URL , start : NSNumber?, duration : NSNumber?)   // trimm Steps - 2
    {   /*
        dispatch_async(dispatch_get_main_queue())
        {
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        */
        let regift: Regift;
        
        if let start = start
        {
            // Trimmed video
            regift = Regift(sourceFileURL: videoURL, destinationFileURL: nil, startTime: start.floatValue, duration: duration!.floatValue, frameRate: frameRate, loopCount: loopCount)
        }
        else
        {
            // Untrimmed
             regift = Regift(sourceFileURL: videoURL, destinationFileURL: nil, frameCount: frameCount, delayTime: delayTime, loopCount: loopCount)
        }
        
        let gitURL = regift.createGif()
        let gif = Gif(Url: gitURL!, VideoUrl: videoURL, Caption: nil) // Note3 Page 51
        displayGif(gif : gif)
    }
    
    /*
     // Note 1 Page 50
    func convertVideoToGif(videoURL : URL)
    {
        let regift = Regift(sourceFileURL : videoURL , frameCount : frameCount, delayTime : delayTime , loopCount : loopCount)
        let gitURL = regift.createGif() // Note2 Page 49
         // displayGif(url: gitURL!) OLD
        
        let gif = Gif(Url: gitURL!, VideoUrl: videoURL, Caption: nil) // Note3 Page 51
        displayGif(gif : gif)
    }
    */
    ///--------------------------
    /*
      OLD
     // Note 1 Page 50
    func displayGif(url : URL)
    {
        //create a instance from the GifEditorViewController
        let gifeditorVC = storyboard?.instantiateViewController(withIdentifier: "GifEditorViewController") as! GifEditorViewController
            gifeditorVC.gifURL = url // Note3 Page 49 | the gifURL was declaration in the GifEditorViewController
            navigationController?.pushViewController(gifeditorVC, animated: true) // Note4 Page 49
    }
 */
    func displayGif(gif : Gif)
    {
        //create a instance from the GifEditorViewController
        let gifeditorVC = storyboard?.instantiateViewController(withIdentifier: "GifEditorViewController") as! GifEditorViewController
            gifeditorVC.gif = gif
            navigationController?.pushViewController(gifeditorVC, animated: true)
    }
    
    @IBAction func presentVideoOptions() /// this Function IS IN Obj-c
    {
        if !UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera)
        {
            //
        }
        else
        {
            let newGifActionSheet = UIAlertController(title: "Create new Gif", message: nil, preferredStyle: UIAlertController.Style.actionSheet)
            
            let recordVideo = UIAlertAction(title: "Record video", style: UIAlertAction.Style.default)
            {
                (UIAlertAction) in
                self.launchVideoCamer()
            }
            
            let chooseFromExisting = UIAlertAction(title: "choose From Existing", style: UIAlertAction.Style.default)
            {
                (UIAlertAction) in
                self.launchLibary()
            }
            
            let cancel = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel,handler: nil)
            
            newGifActionSheet.addAction(recordVideo)
            newGifActionSheet.addAction(chooseFromExisting)
            newGifActionSheet.addAction(cancel)
            
            present(newGifActionSheet, animated: true, completion: nil)
            
            let pinkColor = UIColor(red: 255.0/255.0, green: 65.0/255.0, blue: 112.0/255.0, alpha: 1.0) //Note 1 Page 53
            newGifActionSheet.view.tintColor = pinkColor
            
        }
    }
    
    public func launchLibary()  //
    {
        let recordVideoController = UIImagePickerController()
        recordVideoController.sourceType = UIImagePickerController.SourceType.photoLibrary
        recordVideoController.mediaTypes = [kUTTypeMovie as String]
        recordVideoController.allowsEditing = false
        recordVideoController.delegate = self
        
        present(recordVideoController,animated : true , completion : nil)
        
    }
    public func imagePicker(source : UIImagePickerController.SourceType) -> UIImagePickerController
    {
        let picker = UIImagePickerController()
        picker.sourceType = source
        picker.mediaTypes = [kUTTypeMovie as String]
        picker.allowsEditing = true
        picker.delegate = self
        
        return picker
    }
    

}


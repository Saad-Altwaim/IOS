//
//  Gif .swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 1/15/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
//

import Foundation
import UIKit

class Gif // Note3 Page 51
{
    let url      : URL
    var caption  : String? //let caption  : String?
    let gifImage : UIImage?
    let videoURL : URL
    var gifDate  : Date?

    init(Url : URL , VideoUrl : URL , Caption : String?)
    {
        self.url      = Url
        self.caption  = Caption
        self.gifImage = UIImage.gif(url: Url.absoluteString)! // Note 2 Page 51 
        self.videoURL = VideoUrl
        self.gifDate  = nil
        
    }

    init?(Name : String)
    {
        self.gifImage = UIImage.gif(name: Name)
        return nil
    }
}


//
//  GifEditorViewController.swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 1/10/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
//

import UIKit

class GifEditorViewController: UIViewController ,UITextFieldDelegate// the Name of storyBorad View is : Add a Caption
{
    override func viewDidLoad()
    {
        //self.captionTextfield.resignFirstResponder()
        captionTextfield.delegate = self  /// -KEYBORAD
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(GifEditorViewController.keyboardWillHide)
        , name: UIResponder.keyboardWillHideNotification, object: nil)  /// -KEYBORAD
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        /*
         // Note 1 Page 50
        if let gifURL = gifURL  // Note 1 Page 49 | the value come from UIViewController+Record.swift
        {
            let gifFromRecord = UIImage.gif(url: gifURL.absoluteString) //absoluteString : Page 49
            gifImageView.image = gifFromRecord //after convert the Video to Gif  we will Display in the  gifImageView (UIImageView)
        }
         */
        gifImageView.image = gif?.gifImage // Note3 Page 51
        
       // subscribeToKeyboardNotification()
       // subscribeToKeyboardNotificationH()
    }
    
    override func viewWillDisappear(_ animated: Bool) /// -KEYBORAD
    {
        super.viewWillDisappear(animated)
        unsubscribeToKeyboardNotification()
    }

    @IBOutlet weak var captionTextfield: UITextField!
    @IBOutlet weak var gifImageView: UIImageView!
    //var gifURL : URL? = nil // to hold the URL Gif |this is OLD the new is : var is gif : Gif?
    var Duration : NSNumber?
    var newStartTime : Double?
    var gif : Gif? // to hold the Gif Picture  Note1 Page 51
    /*
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        captionTextfield.placeholder = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        captionTextfield.resignFirstResponder()  // IN Obj-C  [textField resignFirstResponder]
        return true
    }
    */
    
    // -KEYBORAD
       var activeTextField : UITextField? = nil
    
       @objc func keyboardWillShow(_ notification:Notification)
       {
           self.view.frame.origin.y = -getKeyboardHeight(notification)
           var shouldMoveViewUp = false

            // if active text field is not nil
            if let activeTextField = activeTextField
            {

              let bottomOfTextField = activeTextField.convert(activeTextField.bounds, to: self.view).maxY;
              
              let topOfKeyboard = view.frame.height - getKeyboardHeight(notification)

              // if the bottom of Textfield is below the top of keyboard, move up
              if bottomOfTextField < topOfKeyboard
              {
                shouldMoveViewUp = true
              }
            }

            if(shouldMoveViewUp)
            {
                self.view.frame.origin.y = 0
            }
       }
       
       @objc func keyboardWillHide(_ notification:Notification)
       {
           self.view.frame.origin.y = 0
       }
       
       func getKeyboardHeight(_ notification :Notification)-> CGFloat
       {
           let userInfo = notification.userInfo
           let keyboardSize = userInfo?[UIResponder.keyboardFrameEndUserInfoKey]as! NSValue
           
           return keyboardSize.cgRectValue.height
           
       }
       
       func subscribeToKeyboardNotification()
       {
           NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)),
               name: UIResponder.keyboardWillShowNotification, object: nil)
       }
       func subscribeToKeyboardNotificationH(){
          //dismiss(animated: true, completion: nil)
           NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)),
           name: UIResponder.keyboardWillHideNotification, object: nil)
       }


       func unsubscribeToKeyboardNotification()
       {
           NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification,object: nil)
           dismiss(animated: true, completion: nil)
       }
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        subscribeToKeyboardNotification()
        subscribeToKeyboardNotificationH()
    }
       func textFieldShouldReturn(_ textField: UITextField) -> Bool
       {
           textField.resignFirstResponder()
           return true
       }
    
       func textFieldDidBeginEditing(_ textField: UITextField)
       {
         // set the activeTextField to the selected textfield
         self.activeTextField = textField
           
       }
    
    @IBAction func presentPreview(_ sender: Any) // Note1 p52 | the same function is IN obj-C
    {

        let previewVC = storyboard?.instantiateViewController(withIdentifier: "PreviewViewController") as! PreviewViewController //A
        
        self.gif?.caption = self.captionTextfield.text // B
        
        func displayGifWithCaption(regift: Regift) /// add Caption to Gif
        {

            let captionFont = self.captionTextfield.font //D
            let gifURL = regift.createGif(self.captionTextfield.text,font: captionFont)! // create A new Gif including the Caption | E
            let newGif = Gif(Url: gifURL, VideoUrl: self.gif!.videoURL, Caption: self.captionTextfield.text) // create a new instance of the Gif Class | F
            
            previewVC.gif = newGif // G
            navigationController?.pushViewController(previewVC, animated: true)
        }
        // Note 3 Page 55
        if let newDuration = Duration , let gifNewStartTime = newStartTime ///  Handle video seleted from camera
        {
            /// C   - here is the input parmeters to create a GIF from this input  will create a Gif
            let regift = Regift(sourceFileURL: self.gif!.videoURL, destinationFileURL: nil, startTime: Float(gifNewStartTime) , duration: Float(newDuration.doubleValue) , frameRate: 15, loopCount: loopCount)// create a new instance of the Regift Class | C

            displayGifWithCaption(regift: regift)
        }
        else ///  Handle video seleted from photoLibrary
        {
            let regift = Regift(sourceFileURL:  self.gif!.videoURL, destinationFileURL: nil, frameCount: frameCount, delayTime: delayTime, loopCount: loopCount)

            displayGifWithCaption(regift: regift)
        }

    }
       
}


    /// Methods to adjust the keyboard
    /*
    extension GifEditorViewController {
        func subscribeToKeyboardNotifications() {
            NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(GifEditorViewController.keyboardWillShow(_:)),
                                                                       name: UIKeyboardWillShowNotification,
                                                                     object: nil)
            NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(GifEditorViewController.keyboardWillHide(_:)),
                                                                       name: UIKeyboardWillHideNotification,
                                                                     object: nil)
        }

        func unsubscribeFromKeyboardNotifications() {
            NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
            NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
        }

        func keyboardWillShow(notification: NSNotification) {
            if view.frame.origin.y >= 0 {
                view.frame.origin.y -= getKeyboardHeight(notification)
            }
        }

        func keyboardWillHide(notification: NSNotification) {
            if (self.view.frame.origin.y < 0) {
                view.frame.origin.y += getKeyboardHeight(notification)
            }
        }

        func getKeyboardHeight(notification: NSNotification) -> CGFloat {
            let userInfo = notification.userInfo
            let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue // of CGRect
            return keyboardSize.CGRectValue().height
        }
    }
 */
    /// Methods to adjust the keyboard


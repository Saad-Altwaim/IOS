//
//  SavedGifsVewController1.swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 2/14/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
//

import UIKit

class SavedGifsVewController1: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout
{
    
    var savedGifs = [Gif]()
    let cellMargin : CGFloat = 12.0
    
    @IBOutlet weak var emptyView: UIStackView!
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        emptyView.isHidden = (savedGifs.count != 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 5 //savedGifs.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GifCell", for: indexPath) as? GifCell
        else
        {
            fatalError("Error to load data")
        }
       // let gif = savedGifs[indexPath.item]
        // cell.configureForGif(gif: gif)
        return cell
    }
    
    // UICollectionViewDelegateFlowLayout Protocol
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let width = (collectionView.frame.size.width - (cellMargin * 2.0)) / 2.0
        return CGSize(width: width, height: width)
    }

}

//
//  UIViewController+Record.swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 1/10/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
// (https://pinkstone.co.uk/how-to-record-video-files-in-your-ios-app)
// ( https://apple.stackexchange.com/questions/358724/if-we-dont-add-nsphotolibraryaddusagedescription-for-saving-images-to-photo-lib )
// (https://stackoverflow.com/questions/12249878/uiimagepickercontroller-allowsediting-yes-getting-untrimmed-video-after-trimm/12315080)
// (Note 2 Page 54 for The stack Code)

import Foundation
import UIKit
import MobileCoreServices // Note 1 Page 47
import AVFoundation



let frameCount = 16
let delayTime : Float = 0.2
let loopCount = 4 // Means Loop For Ever
let frameRate = 15

extension UIViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    /*
    /// old functions for selecting  the SourceType (Camer)
    
    public func launchVideoCamer() // Old Name   @IBAction func launchVideoCamer()
    {
        let recordVideoController = UIImagePickerController()
        recordVideoController.sourceType = UIImagePickerController.SourceType.camera
        recordVideoController.mediaTypes = [kUTTypeMovie as String] // (kUTTypeImage)Note2 Page 47
        recordVideoController.allowsEditing = true //false // trimm Steps - 1 | Note3 Page 47
        recordVideoController.delegate = self
        
        present(recordVideoController,animated : true , completion : nil) // Note1 Page 48
        
    }
   
    public func launchLibary()  /// old functions for selecting  the SourceType  ( Photo Libary)
    {
        let recordVideoController = UIImagePickerController()
        recordVideoController.sourceType = UIImagePickerController.SourceType.photoLibrary
        recordVideoController.mediaTypes = [kUTTypeMovie as String] // (kUTTypeImage)Note2 Page 47
        recordVideoController.allowsEditing = true //false // trimm Steps - 1 | Note3 Page 47
        recordVideoController.delegate = self
        
        present(recordVideoController,animated : true , completion : nil)
        
    }
    */
    /// The new function
   public func imagePicker(source:UIImagePickerController.SourceType)
    {
        let picker = UIImagePickerController()
        picker.sourceType = source
        picker.mediaTypes = [kUTTypeMovie as String]
        picker.allowsEditing = true
        picker.delegate = self

        present(picker,animated : true , completion : nil)
    }
    
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey  : Any])
    {
    let mediaType = info[UIImagePickerController.InfoKey.mediaType] as! String

     if mediaType == kUTTypeMovie as String // note 2 page 54
     {
        let originalVideoURL = info[UIImagePickerController.InfoKey.mediaURL] as! URL
        let editingComplete = UIImagePickerController.InfoKey(rawValue: "_UIImagePickerControllerVideoEditingEnd") /// last  editing Time
        let editingStart    = UIImagePickerController.InfoKey(rawValue: "_UIImagePickerControllerVideoEditingStart") /// Start editing Time
        var duration: NSNumber? //Note4 Page 55

            let startMilliseconds: Double?
            let completeMilliseconds: Double?

            if let start = info[editingStart] as? Double, let complete = info[editingComplete] as? Double
            {
                startMilliseconds = start
                completeMilliseconds = complete
                duration = NSNumber(value: (completeMilliseconds!) - (startMilliseconds!)) /// calculation to give  the duration Time
            }
            else
            {
                startMilliseconds = nil
                completeMilliseconds = nil
                duration = nil
            }

        cropVideoToSquare(rawVideoURL: originalVideoURL as URL, start_CV: startMilliseconds  , duration_CV: duration)
        
        }
    }

    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) // for the Cancel Button
    {
        dismiss(animated: true ,completion:nil)
    }
    
    /// My personal function func convertVideoToGif(videoURL:URL, start: Double?, duration: NSNumber?) // trimm Steps - 2 | Not1 page 55
    func convertVideoToGif(videoURL:URL, start: Double?, duration: NSNumber?) // trimm Steps - 2 | Not1 page 55
    {
        DispatchQueue.main.async()
        {
            self.dismiss(animated: true, completion: nil) ///  To solve the thread Error
        }
            
        let regift: Regift;

        if let start = start
        {
            // Trimmed
            regift = Regift(sourceFileURL: videoURL , destinationFileURL: nil, startTime:Float(start), duration: Float(duration!.doubleValue), frameRate: frameRate, loopCount: loopCount)
        }
        else
        {
            // Untrimmed
            regift = Regift(sourceFileURL: videoURL , destinationFileURL: nil, frameCount: frameCount, delayTime: delayTime, loopCount: loopCount)
        }

        let gifURL = regift.createGif()
        let gif = Gif(Url: gifURL!, VideoUrl: videoURL , Caption: nil)  // Note3 Page 51
        displayGif(gif: gif,durationTime: duration , theStartTime :start ) // Not2 Page 55
    }
    
    
    /*
     // Note 1 Page 50
    func convertVideoToGif(videoURL : URL)
    {
        let regift = Regift(sourceFileURL : videoURL , frameCount : frameCount, delayTime : delayTime , loopCount : loopCount)
        let gitURL = regift.createGif() // Note2 Page 49
         // displayGif(url: gitURL!) OLD
        
        let gif = Gif(Url: gitURL!, VideoUrl: videoURL, Caption: nil) // Note3 Page 51
        displayGif(gif : gif)
    }
    */
    ///--------------------------
    /*
      OLD
     // Note 1 Page 50
    func displayGif(url : URL)
    {
        //create a instance from the GifEditorViewController
        let gifeditorVC = storyboard?.instantiateViewController(withIdentifier: "GifEditorViewController") as! GifEditorViewController
            gifeditorVC.gifURL = url // Note3 Page 49 | the gifURL was declaration in the GifEditorViewController
            navigationController?.pushViewController(gifeditorVC, animated: true) // Note4 Page 49
    }
 */
    func displayGif(gif : Gif , durationTime: NSNumber? , theStartTime : Double?)
    {
        //create a instance from the GifEditorViewController
        let gifeditorVC = storyboard?.instantiateViewController(withIdentifier: "GifEditorViewController") as! GifEditorViewController
            gifeditorVC.gif = gif // to Display the Gif that was create here in GifEditorViewController
            gifeditorVC.Duration = durationTime
            gifeditorVC.newStartTime = theStartTime
            
            DispatchQueue.main.async()
            {
                self.navigationController?.pushViewController(gifeditorVC, animated: true)
            }
    }
    
    @IBAction func presentVideoOptions() /// this Function IS IN Obj-c
    {
        if !UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera)
        {
            ///
        }
        else
        {
            let newGifActionSheet = UIAlertController(title: "Create new Gif", message: nil, preferredStyle: UIAlertController.Style.actionSheet)
            
            let recordVideo = UIAlertAction(title: "Record video", style: UIAlertAction.Style.default)
            {
                (UIAlertAction) in
                self.imagePicker(source: .camera) /// self.launchVideoCamer() OLD
            }
            
            let chooseFromExisting = UIAlertAction(title: "choose From Existing", style: UIAlertAction.Style.default)
            {
                (UIAlertAction) in
                self.imagePicker(source: .photoLibrary) /// self.launchLibary()  OLD
            }
            
            let cancel = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel,handler: nil)
            
            newGifActionSheet.addAction(recordVideo)
            newGifActionSheet.addAction(chooseFromExisting)
            newGifActionSheet.addAction(cancel)
            
            present(newGifActionSheet, animated: true, completion: nil)
            
            let pinkColor = UIColor(red: 255.0/255.0, green: 65.0/255.0, blue: 112.0/255.0, alpha: 1.0) //Note 1 Page 53
            newGifActionSheet.view.tintColor = pinkColor
            
        }
    }
    /// _cv ==cropVideo
    func cropVideoToSquare( rawVideoURL : URL , start_CV: Double?, duration_CV: NSNumber?) /// this Function IS IN Obj-c
    {
        /// Initialize AVAsset and AVAssetTrack
        let videoAsset = AVURLAsset(url: rawVideoURL) //Note 1 Page 56 | A
        let videoTrack = videoAsset.tracks(withMediaType: AVMediaType.video)[0]//OR [0].first | Note 2 P 56 | B
        
        /// Initialize video composition and set properties
        let videoComposition = AVMutableVideoComposition() // Note 1 Page 57 |C
        videoComposition.renderSize = CGSize(width: videoTrack.naturalSize.height, height: videoTrack.naturalSize.height) // Note 2 Page 57 |D
        videoComposition.frameDuration = CMTime(value: 1, timescale: 30) // Note3 Page 57
        
        /// Initialize instruction and set time range
        let instruction = AVMutableVideoCompositionInstruction() // Note 4 Page 57 |E
        instruction.timeRange = CMTimeRange(start: CMTime.zero, duration: CMTime(seconds: 60, preferredTimescale: 30)) // Note 5 Page 57 |E
         
        ///Center the cropped video
        let transformer = AVMutableVideoCompositionLayerInstruction.init(assetTrack: videoTrack) // Note 6 Page 57 |G
        let firstTransform : CGAffineTransform = CGAffineTransform.init(translationX: videoTrack.naturalSize.height,
                                                y: -( videoTrack.naturalSize.width - videoTrack.naturalSize.height) / 2) // Note 1 Page 58
        
        //Rotate 90 degrees to portrait
        let secondTransform = firstTransform.rotated(by: CGFloat(Double.pi / 2)) // == 90˚ | Note 2 Page 58
        // if firstTransform.rotated(by: CGFloat(Double.pi)) == 180˚
        // if firstTransform.rotated(by: CGFloat(Double.pi * 1.5)) == 270 ˚
         
        let completeTransform = secondTransform
        //Rotate 90 degrees to portrait
        transformer.setTransform(completeTransform, at:CMTime.zero) // Note 3 Page 58 |F
        instruction.layerInstructions = [transformer] // Note 4 Page 58
        videoComposition.instructions = [instruction] // Note 5 Page 58
        
        ///export
        let exporter = AVAssetExportSession.init(asset: videoAsset, presetName: AVAssetExportPresetHighestQuality)  // Note 1 Page 59
        exporter?.videoComposition = videoComposition // Note 2 Page 59
        
        let path = createPath()
        exporter?.outputURL = URL(fileURLWithPath: path) /// Creates a file URL that references the local file or directory at path.
        exporter?.outputFileType = AVFileType.mov //The type of file written by the session
        
        /*
        __block NSURL *croppedURL; this Code in  Obj-c APP line 139 |  the Note4 Page 60
        There is no need for __block in Swift. A captured variable is automatically settable from within the closure.
        */
        
        // Note 1 Page 61
        exporter?.exportAsynchronously(completionHandler:
        {
            let   croppedURL = exporter!.outputURL!
            self.convertVideoToGif(videoURL: croppedURL as URL, start: start_CV as Double? , duration: duration_CV)
            // this Method will export the video from the temp Directory to documentDirectory
            // Reference
            // (https://1989lifejourney.com/2019/12/25/avfoundation-programming-guide-swift-using-assets/)
        })
    }
    
    func createPath() -> String   /// this Function IS IN Obj-c
    {
        let path : NSArray = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask , true) as NSArray // Note 3 Page 59 | // create The path
        let documentsDirectory : NSString = path[0] as! NSString ///This method will return an array of strings, we only want the first element of the array
        let manager = FileManager.default // Note 1 Page 60
        var outputURL : NSString = documentsDirectory.appendingPathComponent("output") as NSString /// Note 2 Page 60
        print("outputURL_1",outputURL)
        do
        {
            try manager.createDirectory(atPath: outputURL as String, withIntermediateDirectories: true, attributes: nil) /// Note 3 Page 60
        }
        catch let error as NSError
        {
            print("Unable to create directory",error)
        }
        
        outputURL = outputURL.appendingPathComponent("output.mov") as NSString
        print("outputURL_2",outputURL)
        do
        {
            try manager.removeItem(atPath: outputURL as String) ///Removes the file or directory at the specified path
        }
        catch let error as NSError
        {
            print("Error cant move the file… | the Error Message :  ",error)
        }
        
        let newoutputURL = outputURL

        return newoutputURL as String
    }
    //advanced-swift-sequences-collections-and-algorithms
    // Reference
    // (https://1989lifejourney.com/2019/12/25/avfoundation-programming-guide-swift-using-assets/)
    func configureExportSession (session : AVAssetExportSession , OutputURL : String , Start : Int , Complete : Int) -> AVAssetExportSession  /// this Function IS IN Obj-c
    {
        session.outputURL = URL(fileURLWithPath: OutputURL)
        session.outputFileType = AVFileType.mov
        let newTimeRange = CMTimeRangeMake(start   : CMTimeMake(value: Int64(Start),timescale: 1000),
                                           duration: CMTimeMake(value: Int64(Complete - Start) , timescale: 1000))
        
        session.timeRange = newTimeRange
    
        return session
        
    }
    

}


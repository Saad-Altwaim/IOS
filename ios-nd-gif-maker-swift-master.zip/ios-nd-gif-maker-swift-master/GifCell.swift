//
//  GifCell.swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 2/14/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
//

import Foundation
import  UIKit



class GifCell : UICollectionViewCell
{
    @IBOutlet weak var gifImageView: UIImageView!
    
    func configureForGif(gif : Gif)
    {
        gifImageView.image = gif.gifImage // Not1 page 64 
    }
    
}

<img src="https://s3-us-west-1.amazonaws.com/udacity-content/degrees/catalog-images/nd003.png" alt="iOS Developer Nanodegree logo" height="70" >

# GifMaker (Swift)

![Platform iOS](https://img.shields.io/badge/nanodegree-iOS-blue.svg)

This repository contains resources for the GifMaker (Swift) project.

## Overview

GifMaker is an app that lets users create simple GIF animations from their iOS device. It is used as an example throughout Udacity's Objective-C for Swift Developers course.

## Setup

GifMaker should run without any additional setup.

## Maintainers

@GabrielleM

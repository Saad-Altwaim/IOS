//
//  RPSGame.h
//  RockPaperScissors
//
//  Created by Saad altwaim on 12/30/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RPSTurn.h"
NS_ASSUME_NONNULL_BEGIN

@interface RPSGame : NSObject
@property (nonatomic) RPSTurn  * firstTame;
@property (nonatomic) RPSTurn  * secondTime;
-(instancetype) initWithFirstTurn : (RPSTurn*) playerTurn  theSecondTime : (RPSTurn*) computerTurn;
@end

NS_ASSUME_NONNULL_END

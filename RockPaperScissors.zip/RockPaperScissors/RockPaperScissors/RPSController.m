//
//  RPSController.m
//  RockPaperScissors
//
//  Created by Saad altwaim on 12/31/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import "RPSController.h"
#import "RPSTurn.h"
@implementation RPSController
- (void) throwDown: (Move) playersMove
{   
    RPSTurn * playersTrun = [[RPSTurn alloc] initWithMove : playersMove ];
    RPSTurn * computerTurn = [[RPSTurn alloc] init];
     
    self.game = [[RPSGame alloc] initWithFirstTurn : playersTrun theSecondTime : computerTurn];
}
@end

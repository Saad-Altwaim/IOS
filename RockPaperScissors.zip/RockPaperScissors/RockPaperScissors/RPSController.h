//
//  RPSController.h
//  RockPaperScissors
//
//  Created by Saad altwaim on 12/31/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RPSGame.h"
NS_ASSUME_NONNULL_BEGIN

@interface RPSController : NSObject
@property (nonatomic) RPSGame *game ;
@end

NS_ASSUME_NONNULL_END

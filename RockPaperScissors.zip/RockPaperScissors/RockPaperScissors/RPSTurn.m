//
//  RPSTurn.m
//  RockPaperScissors
//
//  Created by Saad altwaim on 12/30/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import "RPSTurn.h"

@implementation RPSTurn
-(instancetype)initWithMove:(Move) move
{
    self = [super init];

    if (self){
        _move = move;
    }

    return self;
}
-(instancetype)init
{
    self = [super init];

    if (self){
        _move = [self generateMove];
    }

    return self;
}

-(Move) generateMove //page 38 [10]
{
    NSUInteger randomNumber = arc4random_uniform(3); // random 1 -2

    switch(randomNumber)
    {
        case 0 :
            return Rock;
        break;
        
        case 1 :
            return Paper;
            break;
        
        case 3 :
            return Scissors;
            break;
         
        default:
            return invalid;
            break;
    }
    return Rock;
} // Page 35 / 36 not1
//-(NSString * )description{return self;};
 
-(BOOL) defeats:(RPSTurn * )opponent {return false;} // Page 35 not2
@end



//
//  RPSGame.m
//  RockPaperScissors
//
//  Created by Saad altwaim on 12/30/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import "RPSGame.h"

@implementation RPSGame
-(instancetype) initWithFirstTurn : (RPSTurn * ) playerTurn  theSecondTime : (RPSTurn * ) computerTurn
 {
    self = [super init];
    
    if (self)
    {
        _firstTame = playerTurn;
        _secondTime = computerTurn;   
    }
    return self;
}
@end

//
//  RPSTurn.h
//  RockPaperScissors
//
//  Created by Saad altwaim on 12/30/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>
 
typedef NS_ENUM(NSInteger,Move)
{
    Rock,
    Paper,
    Scissors,
    invalid
};

NS_ASSUME_NONNULL_BEGIN

@interface RPSTurn : NSObject
@property (nonatomic) Move move;

-(instancetype)initWithMove:(Move) move;
//-(NSString * )description;
-(BOOL) defeats:(RPSTurn * )opponent ;
@end

NS_ASSUME_NONNULL_END

//
//  breedListResponse.swift
//  RandomDogAPI
//
//  Created by Saad altwaim on 8/15/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import Foundation

struct BreedListResponse :Codable
{
    let message : [String : [String]]
    let status  : [String]
}

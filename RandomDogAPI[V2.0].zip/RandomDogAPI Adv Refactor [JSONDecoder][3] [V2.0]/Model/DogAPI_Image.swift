//
//  DogAPI_Image.swift
//  RandomDogAPI
//
//  Created by Saad altwaim on 8/7/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import Foundation

struct DagImage : Codable
{
    let message : String
    var status  : String
}

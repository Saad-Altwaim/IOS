//
//  DogAPI.swift
//  RandomDogAPI
//
//  Created by Saad altwaim on 8/7/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import Foundation
import UIKit

class dogAPI
{
    enum Point // Pape 154 [13] - page 155
    {
        case randomImageFromAllDogCollection // the First Case Page 154
        
        var Url : URL // Computed property Page 145 
        {
            return URL(string: self.stringValues)!
        }
        // for More INFO page 86
        //case randomImageForBreed(String) // the seond Case Page 154
        
        case randomImageForBreed2(String)
        case listAllBreed2
        
        var stringValues: String
        {
            switch self
            {
                case .randomImageFromAllDogCollection :
                    return "https://dog.ceo/api/breeds/image/random"
                case .randomImageForBreed2(let breed):
                    return "https://dog.ceo/api/breed/\(breed)/images/random"
                case .listAllBreed2:
                return "https://dog.ceo/api/breeds/list/all"
                default:
                    print("Error IN URL")
            }
        }
        
    }
    // note 1
    
    class func requestBreedList2(completionHandler: @escaping ([String] , Error? )-> Void)
    {
        let task = URLSession.shared.dataTask(with: Point.listAllBreed2.Url)
        {
                  (urlPointData, respons, error) in
                  guard let dataRequest = urlPointData // test if ThTP Request from thr API URL is working good
                  else
                  {
                      completionHandler([],error) //Page 155 [15] Note -1
                      print("the Point.listAllBreed.Url :",Point.listAllBreed2.Url)
                      print("Error NO URL requestBreedList ")
                      return
                  }
                  
                  print("The Data from the API Request  requestBreedList IS ",dataRequest) //the Respons
                  
                  let decoder2 = JSONDecoder() // create the parsing Opject
            do
            {
                  let breedResponse = try decoder2.decode(BreedListResponse.self, from: dataRequest)
                  let breeds = breedResponse.message.keys.map({$0}) // Note 2 [15] page 155
                  print("The Message from the New Struct BreedListResponse :",breeds)
                  completionHandler(breeds,nil)
            }
            catch
            {
                print(Error.self)
            }

      }
      task.resume()
    }
    
    class func requestImageFile(url :URL ,completionHandler: @escaping (UIImage? , Error? )-> Void)
    {
        let MY_task = URLSession.shared.dataTask(with: url) //note_2 page 147
        {
            (data, respons, error) in
            guard let imageData = data // the data of the Image that come form the http Request
            else  // Handler the respones
            {
                completionHandler(nil,error)
                print("Error no Image found 2 ")
                return
            }
            let url_loadImage = UIImage(data: imageData) // convert the data of the Image (that come form the http Request) to Image
            completionHandler(url_loadImage,nil) // save here in call in view controller page  handleImageFileRespons
        }
        MY_task.resume()
    }
    // [16]
    // -- the First Request --\\
    // ##this is the struct (DagImage?) the parmeter for closure --  see /* #1# */
    // after the function work .the completionHandler will start work
    class func requestRandomImage(breed : String ,completionHandler: @escaping (DagImage?,Error?)-> Void )
    {    // the Enum is dynamc -> (breedType)
        let ulrPoint = dogAPI.Point.randomImageForBreed2(breed).Url // The Enum
        print(ulrPoint)
        let task = URLSession.shared.dataTask(with: ulrPoint) // create the HTTP Request from thr API URL
        {
            (urlPointData, respons, error) in
            guard let dataRequest = urlPointData // test if ThTP Request from thr API URL is working good
            else
            {
                completionHandler(nil,error)
                print("Error NO URL requestRandomImage ")
                return
            }
            
            print("The Data from the API Request IS requestImageFile ",dataRequest) //the Respons
            
            let decoder = JSONDecoder() // create the parsing Opject

            do
            {   // use the Decode function to convert the from json obj to the Enum DogAPI_Image.swift
                // the josn opj is in (dataRequest)  & the Enum is the (DogImage)  the file is  [DogAPI_Image.swift]
                let imageData = try decoder.decode(DagImage.self, from: dataRequest)
                print("The Message from the New protocol is :",imageData)
  /* #1# */     completionHandler(imageData,nil) // save here in call in view controller page the mothed Helper (handleRandomImageRespons)
                // the compltion handelr take  struct (DagImage?) becuse will take json obj after convert to stuct & we call to the handleRandomImageRespons)
            }
            catch
            {
                    
            }
        }
        task.resume()
    }
}

//let oldStyaly = dogAPI.Point.randomImageFromAllDogCollection.rawValue
//var oldUrlStyle = URL(string: oldStyaly)!


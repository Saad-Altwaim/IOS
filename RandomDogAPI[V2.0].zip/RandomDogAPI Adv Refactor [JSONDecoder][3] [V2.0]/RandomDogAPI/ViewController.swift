//
//  ViewController.swift
//  RandomDogAPI
//
//  Created by Saad altwaim on 8/7/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//
//  Page 152 [12]

import UIKit

//class ViewController: UIViewController ,UIPickerViewDataSource,UIPickerViewDelegate   //  [number Two Method] page 153
class ViewController: UIViewController
{
    @IBOutlet weak var dogPickerView: UIPickerView!
    @IBOutlet weak var ImageView: UIImageView!
    
    var breedsList : [String]  = [] // for All One Method [ 1,2]
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("the new Enum print",dogAPI.Point.listAllBreed2.Url)
        //print("the Old print" ,oldUrlStyle) // from The dogAPI.swift Page
        
        dogPickerView.dataSource = self // for All One Method [ 1,2]
        dogPickerView.delegate = self   // for All One Method [ 1,2]
        dogAPI.requestBreedList2(completionHandler: handleBreedListResponse(breeds: Error:))
    }
        
    func handleBreedListResponse(breeds :[String] , Error :Error?)
    {
        print("handleBreedListResponse",breeds)
        self.breedsList = breeds
        DispatchQueue.main.async // make this URL session to the main Thread
        {
            self.dogPickerView.reloadAllComponents()
        }
    }
    func handleRandomImageRespons(imageData:DagImage?,error:Error?)
    {
        // if the message is nil [empty String (?? "")]
        guard let urlImageDate = URL(string: imageData?.message ?? "") //NOTE_1 Page 147
        else
        {
            print("Error IN MYcode")
            return
        }
        dogAPI.requestImageFile(url: urlImageDate , completionHandler: self.handleImageFileRespons(viewImage: Error:))// aWorkingCode After Refactor
    }
        
     func handleImageFileRespons(viewImage :UIImage?,Error :Error?)
     {
         DispatchQueue.main.async // make this URL session to the main Thread
         {
             self.ImageView.image = viewImage // show the Image in outlet
         }
     }
    /* // [number two Method] page 153
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return breeds.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
       return breeds[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        dogAPI.requestRandomImage(completionHandler: handleRandomImageRespons(imageData:error:))
    }
    
   */
}
extension ViewController: UIPickerViewDataSource,UIPickerViewDelegate //  [number one  Method] page 154
{
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return breedsList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
       return breedsList[row] // here We chose he breed name from the USER select
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {   //page155
        dogAPI.requestRandomImage(breed: breedsList[row], completionHandler: handleRandomImageRespons(imageData:error:))
    } // we will put the breedsList[row] in the function 
}


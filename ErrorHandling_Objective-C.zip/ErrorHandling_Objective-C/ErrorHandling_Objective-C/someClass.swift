//
//  someClass.swift
//  ErrorHandling_Objective-C
//
//  Created by Saad altwaim on 3/26/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
// (https://levelup.gitconnected.com/advanced-error-handling-in-swift-5-38795c30b7c)



 
import Cocoa

enum MyError : String , Error
{
    case TypicalReason = "I got stuck in traffic"
    case WeirdReason   = "A llama spit on my laptop"
}

public class SomeClass1 : NSObject // not 1 Page 83
{
    public func doSomeThingThatMightFail() throws // Page 82 Not3  | Page 83 
    {
        let number = arc4random_uniform(3)
        switch (number)
        {
            case 0:
                print(number)
                print(MyError.TypicalReason.rawValue)
                throw MyError.TypicalReason
            case 1:
                print(number)
                print(MyError.WeirdReason.rawValue)
                throw MyError.WeirdReason
            default:
                print(number)
                print("Every Thing is Cool.")
        }
        
    }
    
    public func prefromSomeAction() throws
    {
        print("Hi from prefromSomeAction function ")
    }
}

//
//  SomeSwiftClass.swift
//  ErrorHandling_Objective-C
//
//  Created by Saad altwaim on 3/28/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

import Foundation

import Cocoa

@objc enum MyIntError : Int , Error
{
    case TypicalReason = 997
    case WeirdReason   = 998
}

 public class SomeSwiftClass : NSObject
{
    
    public func doSomeThingThatMightFail() throws 
    {
        let number = arc4random_uniform(3)
        switch (number)
        {
            case 0:
                throw MyIntError.TypicalReason
            case 1:
                throw MyIntError.WeirdReason
            default:
                print("The Number is : ",number)
                print("Every Thing is Cool 2 .")
        }
        
    }
    
    func processError()
    {
        let thing = SomeClass1()
        
        do
        {
            try thing.prefromSomeAction()
        }
            
        catch CocoaError.fileReadNoSuchFile // Page 83 Not1 
        {
            print("No such File")
        }
            
        catch let error as Error
        {
            print("The following Error occurred : \(error)")
        }
    }
    

}

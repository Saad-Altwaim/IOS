//
//  NSObject+someClass.h
//  ErrorHandling_Objective-C
//
//  Created by Saad altwaim on 3/26/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <AppKit/AppKit.h>


#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface someClass : NSObject
-(BOOL) doSomethingThatMightFailWithError : (NSError **) error;
@end

NS_ASSUME_NONNULL_END

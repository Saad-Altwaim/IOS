//
//  NSObject+someClass.m
//  ErrorHandling_Objective-C
//
//  Created by Saad altwaim on 3/26/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import "NSObject+someClass.h"

#import <AppKit/AppKit.h>


@implementation someClass: NSObject
-(BOOL) doSomethingThatMightFailWithError:(NSError *__autoreleasing  _Nullable *)error
{
 
    return false;
}
@end

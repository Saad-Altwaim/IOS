//
//  main.m
//  ErrorHandling_Objective-C
//
//  Created by Saad altwaim on 3/26/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+someClass.h"
#import "ErrorHandling_Objective_C-Swift.h" // page 82 Note 1 / 2


int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        /*
         // if we want to use objc block Code \\
         
        someClass * instance = [[someClass alloc]init];
        NSError * error = nil;
        BOOL success = [instance doSomethingThatMightFailWithError: &error];
        
        if(!success)
        {
            NSLog(@"Error Code %@", error.domain);
        }
        */
        
        Error_Handling * swiftError = [[Error_Handling alloc]init];
        
       // [swiftError errorCatch];
      //  [swiftError errorPrint];
        
        NSError * error;
        
        [swiftError doSomethingThatMightFailAndReturnErrorWithError:error];
        
        if(!error)
        {
            NSLog(@"Error occurred with domain : %@ and code %ld" , error.domain , (long)error.code);
        }

        
        
        
    }
    return 0;
}

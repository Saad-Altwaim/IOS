//
//  Main.swift
//  ErrorHandling_Objective-C
//
//  Created by Saad altwaim on 3/26/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//
// Page 82 [10]



import Foundation

var instane = SomeClass1()

var swiftClass = SomeSwiftClass()

@objc class Error_Handling : NSObject
{
    @objc func errorCatch()
    {
        do
        {
            try instane.doSomeThingThatMightFail()
        }
        
        catch let error as MyError
        {
            print("The following Error occurred : \(error)")
        }
        
        catch
        {
            print("unknown Error Occurred")
        }
    }
    
    @objc func errorPrint()
    {
        do
        {
            try instane.doSomeThingThatMightFail()
        }
            
        catch let error2 as MyError
        {
            print("\(error2)")
        }
        catch
        {
            print("unknown Error Occurred 2")
        }
    }
    
    @objc func doSomethingThatMightFailAndReturnError(error : NSError)
    {
        do
        {
            try swiftClass.doSomeThingThatMightFail()
        }
        catch let error1 as MyIntError
        {
            print("The following Error occurred 2 _: \(error1.localizedDescription)")
        }
        catch
        {
            print("unknown Error Occurred 2")
        }
    }

}


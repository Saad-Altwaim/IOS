//
//  PrintBugViewController.swift
//  SoManyBugs
//
//  Created by Jarrod Parkes on 4/16/15.
//  Copyright (c) 2015 Jarrod Parkes. All rights reserved.
//

import UIKit

// MARK: - PrintBugViewController: UIViewController

class PrintBugViewController: UIViewController {

    // MARK: Properties
    
    let bugFactory = BugFactory.sharedInstance()
    let maxBugs = 100
    let moveDuration = 3.0
    let disperseDuration = 1.0    
    var bugs = [UIImageView]() // Note 3 page 203

    // MARK: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()        
        let singleTapRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleSingleTap))
        view.addGestureRecognizer(singleTapRecognizer)                
    }

    // MARK: Bug Functions
    
    func addBugToView() // Note 1 page 202
    {
        print(self) // Note 2 page 203
        debugPrint(self) // Note 2 page 203
        print("The Total number for the bugs is :\(bugs.count) bug Maximum : \(maxBugs)") // Note 3 page 202
        if bugs.count < maxBugs
        {
            let newBug = bugFactory.createBug()
            bugs.append(newBug) // Note 2 page 202
            view.addSubview(newBug) // Note 4 page 202
            moveBugsAnimation()
        }
        print("The new Value for Bug is : \(bugs.count)") // Note 3 page 202
        debugPrint(self) // Note 2 page 203
        print(self) // Note 2 page 203
    }

    func emptyBugsFromView() {
        for bug in self.bugs {
            bug.removeFromSuperview()
        }
        self.bugs.removeAll(keepingCapacity: true)
    }
    
    // MARK: View Animations
    
    func moveBugsAnimation() {
        UIView.animate(withDuration: moveDuration) {
            for bug in self.bugs {
                let randomPosition = CGPoint(x: CGFloat(arc4random_uniform(UInt32(UInt(self.view.bounds.maxX - bug.frame.size.width))) + UInt32(bug.frame.size.width/2)), y: CGFloat(arc4random_uniform(UInt32(UInt(self.view.bounds.maxY - bug.frame.size.height))) + UInt32(bug.frame.size.height/2)))
                bug.frame = CGRect(x: randomPosition.x - bug.frame.size.width/1.5, y: randomPosition.y - bug.frame.size.height/1.5, width: BugFactory.bugSize.width, height: BugFactory.bugSize.height)
            }
        }
    }
    
    func disperseBugsAnimation() {
        UIView.animate(withDuration: disperseDuration, animations: { () -> Void in
            for bug in self.bugs {
                let offScreenPosition = CGPoint(x: (bug.center.x - self.view.center.x) * 20, y: (bug.center.y - self.view.center.y) * 20)
                bug.frame = CGRect(x: offScreenPosition.x, y: offScreenPosition.y, width: BugFactory.bugSize.width, height: BugFactory.bugSize.height)
            }
        }, completion: { (finished) -> Void in
            if finished { self.emptyBugsFromView() }
        })
    }
    
    // MARK: Actions
    
    @IBAction func popToMasterView() {
        let _ = navigationController?.popToRootViewController(animated: true)
    }
}

// MARK: - UIResponder

extension PrintBugViewController { // Note 1 page 203
    override var canBecomeFirstResponder: Bool { return true }
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake { disperseBugsAnimation() }
    }
    @objc func handleSingleTap(_ recognizer: UITapGestureRecognizer) { addBugToView() }
}
extension PrintBugViewController   // Note 2 page 203
{
    override var description: String // to print this value we use print(self) IN the addBugToView function
    {
        return "The PrintBugViewController Contains \(bugs.count) Bugs "
    }
}

extension PrintBugViewController // Note 2 page 203
{
    override var debugDescription: String //to print this value we use debugPrint(self) IN the addBugToView function
    {
        var index = 0
        var debugString = "[Message] The PrintBugViewController Contains \(bugs.count) Bugs...\n "
        for bug in bugs
        {
            debugString = debugString + "BUG\(index): \(bug.frame)\n" // Note 3 page 203
            
            index += 1
        }
        return debugString
    }
}

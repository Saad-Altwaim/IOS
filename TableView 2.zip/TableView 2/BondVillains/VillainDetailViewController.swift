//
//  VillainDetailViewController.swift
//  BondVillains
//
//  Created by Saad altwaim on 6/26/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit

class VillainDetailViewController: UIViewController {

    var villain: Villain! // struct
    
    @IBOutlet weak var myIamge1: UIImageView!
    @IBOutlet weak var mylabel1: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.mylabel1!.text = self.villain.name
        self.myIamge1!.image = UIImage(named: villain.imageName)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

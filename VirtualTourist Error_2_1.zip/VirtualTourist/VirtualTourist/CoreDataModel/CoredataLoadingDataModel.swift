//
//  CoredataLoadingDataModel.swift
//  VirtualTourist
//
//  Created by Saad altwaim on 10/6/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

import Foundation
import UIKit

class CoreDataLoadingDataModel
{
    static var dataList = [UIImage]()
}

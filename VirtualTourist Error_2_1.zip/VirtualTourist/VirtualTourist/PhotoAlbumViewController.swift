//
//  PhotoAlbumViewController.swift
//  VirtualTourist
//
//  Created by Saad altwaim on 9/8/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class PhotoAlbumViewController: UIViewController , MKMapViewDelegate , UICollectionViewDelegate , UICollectionViewDataSource
//    , NSFetchedResultsControllerDelegate
{
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var collectionViewButton: UIButton!
    
    var dataController : DataController?
    var pin : Pin?
    var isPinExist : Bool? // Page 17 Note 1
    var fetchedResultsController : NSFetchedResultsController<Photo>!
    
//    var blockOperations: [BlockOperation] = []
//    deinit {
//        // Cancel all block operations when VC deallocates
//        for operation: BlockOperation in blockOperations {
//            operation.cancel()
//        }
//
//        blockOperations.removeAll(keepingCapacity: false)
//    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        createNavButton(title: "OK", imageName: "Button2.png")
        
        createCellLayout(numberOfItemsPreRow : 3.0 , leftAndRightPaddings : 32.0 ,heightAdjustment : 32.0)
                
        setUpFetchedResultsController()
        
        flickrApiCaller() //Page 18 Note 3 -A
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        navigationController?.setNavigationBarHidden(false, animated: animated)
        
        setUpFetchedResultsController()

    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        
        resetCollectionView()
    }
    
    override func viewDidDisappear(_ animated: Bool)
    {
        super.viewDidDisappear(animated)
        fetchedResultsController = nil
    }
    
    func createNavButton(title: String , imageName : String) // Page 11 Note 3 
    {
        let backbutton = UIButton(type: .custom)
        backbutton.setImage(UIImage(named: imageName), for: .normal)
        backbutton.setTitle(title, for: .normal)
        backbutton.setTitleColor(backbutton.tintColor, for: .normal)
        backbutton.addTarget(self, action: #selector(self.backButton), for: .touchUpInside)

        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backbutton)
        
        showSelectedPin()
    }

    @objc func backButton()
    {
        navigationController?.popViewController(animated: true)
    }
    
    func showSelectedPin()
    {
        let lat = FlickrApiClient.LocationVariable.latitude
        let lon = FlickrApiClient.LocationVariable.longitude
        
        let annotation = MKPointAnnotation()
        let location = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        annotation.coordinate = location
        let span = MKCoordinateSpan(latitudeDelta: 1.3, longitudeDelta: 1.3)
        let region = MKCoordinateRegion(center: annotation.coordinate, span: span)
        
        mapView.setRegion(region, animated: true)
        mapView.addAnnotation(annotation)
        
//        displayFlickrApiPhoto()
    }

    func displayFlickrApiPhoto()
    {
        FlickrApiClient.getFlickrPhotosSearchForLocation
        {
            (flickrPhoto , error) in
//            print("message from view contrller" , flickrPhoto)
            
            FlickerDataModel.dataList = flickrPhoto
             
            if (FlickerDataModel.dataList == [] || error != nil)
            {
                DispatchQueue.main.async
                {
                    let alertVC = UIAlertController(title: "Error", message: "No Image was found in this Location", preferredStyle: .alert)
                    let alertButton = UIAlertAction(title: "OK", style: .default,
                                                    handler: { (action) -> Void in
                                                    self.navigationController?.popViewController(animated: true)})
                    alertVC.addAction(alertButton)
                    self.present(alertVC,animated: true, completion: nil)
                }
            }
                
            else
            {
//                print("NO Error in PhotoAlbumViewController")
//                print("FlickerDataModel",FlickerDataModel.dataList.count)
                
                DispatchQueue.main.async
                {
                    self.collectionView.reloadData()
                }
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        guard annotation is MKPointAnnotation else { print("no mkpointannotaions"); return nil }
        
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if (pinView == nil)
        {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.image = UIImage(named: "mapPin1")
        }
        else
        {
            pinView!.annotation = annotation
        }
        return pinView
    }
    
    func resetCollectionView()
    {
        FlickerDataModel.dataList = []
        collectionView.reloadData()
    }
    
    // MARK: - Coredata Operation
    
//    func saveImagesToCoredata(iamgeUrl : URL)
//    {
//        if let imageData = try? Data(contentsOf: iamgeUrl)
//        {
//            if let image = UIImage(data: imageData)
//            {
//                let pngImageData = image.pngData() // Page 16
//                let photo = Photo(context: self.dataController!.viewContext)
//                photo.locationPhotos = pngImageData
//                photo.pin = self.pin // Note D Page 15
//
//                do
//                {
//                    try self.dataController?.viewContext.save()
//                    print("The image was save in core COREDATA")
//                }
//                catch
//                {
//                    print(error.localizedDescription)
//                    print(error)
//                    print("Cant save IMAGE TO COREDATA")
//                }
//            }
//        }
//    }
    
//    func saveImagesToCoredataUsingAsyncAfter(iamgeUrl : URL)
//    {
//        if let imageData = try? Data(contentsOf: iamgeUrl)
//        {
//            if let image = UIImage(data: imageData)
//            {
//                DispatchQueue.main.asyncAfter(deadline: .now() + 3)// Page 163 Note 2
//                {
//                    let pngImageData = image.pngData() // Page 16
//                    let photo = Photo(context: self.dataController!.viewContext)
//                    photo.locationPhotos = pngImageData
//                    photo.pin = self.pin // Note D Page 15
//                    try? self.dataController?.viewContext.save()
//                    print("The image was save in COREDATA using asyncAfter ")
//                }
//            }
//        }
//    }
    
    func flickrApiCaller()
    {
        let fetchRequest : NSFetchRequest<Photo> = Photo.fetchRequest() // Note 1 Page 16
        let predicate = NSPredicate(format: "pin == %@", pin!)
          
        fetchRequest.predicate = predicate
          
        if let result = try? dataController?.viewContext.fetch(fetchRequest)
        {
            if (result.count == 0)
            {
                displayFlickrApiPhoto()
            }
        }
    }
    
//    func saveImageToCoredataUsingBackgroundContext(imageUrl : URL)
//    {
//        let backgroundContext : NSManagedObjectContext! = dataController?.backgroundContext
//
//        if let imageData = try? Data(contentsOf: imageUrl)
//        {
//            if let image = UIImage(data: imageData)
//            {
//                backgroundContext.perform
//                {
//                    let photo = Photo(context: self.dataController!.backgroundContext)
//                    let phtotID = photo.objectID
//
//                    let pinID = self.pin?.objectID
//                    let backgroundPin = self.dataController?.backgroundContext.object(with: pinID!) as! Pin // Note 2 Page 18 - B
//
//                    let pngImagesData = image.pngData()
//                    let backgroundPhoto = backgroundContext.object(with: phtotID) as! Photo // Note 2 Page 18 - A
//                    backgroundPhoto.locationPhotos = pngImagesData // Note 2 Page 18 - C
//                    backgroundPhoto.pin = backgroundPin
//
//                    if backgroundContext.hasChanges
//                    {
//                        do
//                        {
//                            try backgroundContext.save()
//                            print("The image was save in core COREDATA Using background Context")
//                        }
//                        catch
//                        {
//                            print(error)
//                            print("Cant save IMAGE TO COREDATA background Context")
//                        }
//                    }
//                }
//            }
//        }
//    }
    
    func downloadImage( imagePath:String, completionHandler: @escaping (_ imageData: Data?, _ errorString: String?) -> Void)
    {
        let session = URLSession.shared
        let imgURL = NSURL(string: imagePath)
        let request: NSURLRequest = NSURLRequest(url: imgURL! as URL)
        let task = session.dataTask(with: request as URLRequest)
        {
            data, response, downloadError in
            if downloadError != nil
            {
                completionHandler(nil, "Could not download image \(imagePath)")
            }
            
            else
            {
                completionHandler(data, nil)
          
            }
        }
        task.resume()
    }
    
    func downloadUsingNewMethod(data :Data)
    {
        if let image = UIImage(data: data)
        {
            let backgroundContext : NSManagedObjectContext! = self.dataController?.backgroundContext
            
            backgroundContext.perform
            {
                let photo = Photo(context: self.dataController!.backgroundContext)
                let phtotID = photo.objectID

                let pinID = self.pin?.objectID
                let backgroundPin = self.dataController?.backgroundContext.object(with: pinID!) as! Pin // Note 2 Page 18 - B

                let pngImagesData = image.pngData()
                let backgroundPhoto = backgroundContext.object(with: phtotID) as! Photo // Note 2 Page 18 - A
                backgroundPhoto.locationPhotos = pngImagesData // Note 2 Page 18 - C
                backgroundPhoto.pin = backgroundPin

                if backgroundContext.hasChanges
                {
                    do
                    {
                        try backgroundContext.save()
                        print("The image was save in core COREDATA Using background Context")
                    }
                    catch
                    {
                        print(error)
                        print("Cant save IMAGE TO COREDATA background Context")
                    }
                }
            }
        }
    }
    
    func deleteImageFromCoredata(at indexPath : IndexPath)
    {
        let iamgeToDelete = fetchedResultsController.object(at: indexPath)
        dataController?.viewContext.delete(iamgeToDelete)
        
        if dataController?.viewContext.hasChanges == true
        {
            try? dataController?.viewContext.save()
        }
    }
    
    // MARK: - fetchedResultsController
    
    fileprivate func setUpFetchedResultsController()
    {
        let fetchRequest : NSFetchRequest<Photo> = Photo.fetchRequest()
        let pinObjectID = self.pin?.objectID
        let pinFromBackgroung = self.dataController?.backgroundContext.object(with: pinObjectID!) as! Pin
        let predicate = NSPredicate(format: "pin == %@", pinFromBackgroung)
        let sortDescriptor = NSSortDescriptor(key: "locationPhotos", ascending: true)
        
        fetchRequest.predicate = predicate
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest,
                                                              managedObjectContext: dataController!.viewContext,
                                                              sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        
        do
        {
            try fetchedResultsController.performFetch()
        }
            
        catch
        {
            print("The Error Message is : ",error)
            fatalError("The Fetch Could Not be preformed : \(error.localizedDescription)")
        }
        
    }
    
    @IBAction func newCollectionButton(_ sender: Any)
    {
        displayFlickrApiPhoto()
    }

    func createCellLayout(numberOfItemsPreRow : CGFloat , leftAndRightPaddings : CGFloat ,heightAdjustment :  CGFloat) // Page 11 Note 4
    {
        let width  = (collectionView!.frame.width - leftAndRightPaddings) / numberOfItemsPreRow
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: width, height: width + heightAdjustment)
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        if let sections = fetchedResultsController.sections
        {
            return sections.count
        }
        else
        {
            return 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        //Page 18 Note 3 -B (in the next Page)
        let isRecordExist = fetchedResultsController.sections?[section].numberOfObjects
        
        if isRecordExist != 0
        {
            guard let sections = fetchedResultsController.sections
            
            else
            {
                return 0
            }
            
            isPinExist = true
            let sectionInfo = sections[section]
            return sectionInfo.numberOfObjects
        }
            
        else
        {
            isPinExist = false
            return FlickerDataModel.dataList.count
        }
        
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if(isPinExist == false)
        {
            FlickerDataModel.dataList.remove(at: indexPath.item)
            self.collectionView.deleteItems(at: [indexPath])
        }
        else
        {

            deleteImageFromCoredata(at: indexPath)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        // Page 13 note 1 
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FlickrCollectionViewCell", for: indexPath) as! CollectionViewCell
        
        if isPinExist != false
        {
            let aPhoto = fetchedResultsController.object(at: indexPath)
            let imageData = aPhoto.locationPhotos
            let uiIamge = UIImage(data: imageData!)

            cell.imageView.image = uiIamge
        }
                
        else
        {
            let DataModel = FlickerDataModel.dataList[indexPath.row]

            cell.imageView.image = UIImage(named: "placeholder1")

            let urlString = "https://live.staticflickr.com/\(DataModel.server)/\(DataModel.id)_\(DataModel.secret)_m.jpg"
//            print("The Flicker URL IS :  ",urlString)

            let imageUrl = URL(string: urlString)

//            saveImagesToCoredata(iamgeUrl: imageUrl!) // page 18 - A
//            saveImageToCoredataUsingBackgroundContext(imageUrl: imageUrl!) // page 18 - B
//            saveImagesToCoredataUsingAsyncAfter(iamgeUrl: imageUrl!)
            
//            DispatchQueue.global().async
//            {
//                let data = try? Data(contentsOf: imageUrl!)
//
//                DispatchQueue.main.async
//                {
//                    cell.imageView.image = UIImage(data: data!)
//                }
//            }
            downloadImage(imagePath: urlString)
            {
                (Data, String) in
                self.downloadUsingNewMethod(data: Data!)
            }

            let disabledButton = collectionViewButton
            cell.imageView.loadImage(fromURL: imageUrl!, placeHolderImage : "placeholder1", button: disabledButton!) // old cell Code Page 13 - 1

            collectionViewButton.isEnabled = false
        }
        
        return cell
    }
    
}
/*

// old cell Code Page 13 - 2
 
 cell.imageView.image = UIImage(named: "placeholder1")
 DispatchQueue.global(qos: .utility).async
 {
     [weak self] () -> Void in
     let urlString = "https://live.staticflickr.com/\(DataModel.server)/\(DataModel.id)_\(DataModel.secret)_t.jpg"
     print("The Flicker URL IS :  ",urlString)
     
     let data = try? Data(contentsOf: URL(string: urlString)!)
     guard self != nil else { return }
     
     DispatchQueue.main.async
     {
         () -> Void in
         let image = UIImage(data: data!)
         cell.imageView.image = image
     }
 }
 
 ----------------------------------------------------
 
 
 let urlString = "https://live.staticflickr.com/\(DataModel.server)/\(DataModel.id)_\(DataModel.secret)_t.jpg"
 print("The Flicker URL IS :  ",urlString)
 
 let imageUrl = URL(string: urlString)
 self.saveImageToCoredataUsingBackgroundContext(imageUrl: imageUrl!)
 
 DispatchQueue.global(qos: .utility).async
 {
     [weak self] () -> Void in
     let urlString = "https://live.staticflickr.com/\(DataModel.server)/\(DataModel.id)_\(DataModel.secret)_t.jpg"
     print("The Flicker URL IS :  ",urlString)
     let imageUrl = URL(string: urlString)
     let data = try? Data(contentsOf:imageUrl!)
     guard self != nil else { return }
     
     DispatchQueue.main.async
     {
         () -> Void in
         let image = UIImage(data: data!)
         cell.imageView.image = image
     }
 }
 */

extension PhotoAlbumViewController : NSFetchedResultsControllerDelegate
{
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?,
                                                                                    for type: NSFetchedResultsChangeType,
                                                                                    newIndexPath: IndexPath?)

    {
        switch type
        {
            case .insert:
            DispatchQueue.main.async
            {
                self.collectionView!.numberOfItems(inSection: 0)
                self.collectionView.insertItems(at: [newIndexPath!])
            }
            break

            case .delete:
            DispatchQueue.main.async
            {
                self.collectionView!.numberOfItems(inSection: 0)
                self.collectionView.deleteItems(at: [indexPath!])
            }
            break

            case .update:
            DispatchQueue.main.async
            {
                self.collectionView.numberOfItems(inSection: 0)
                self.collectionView.reloadItems(at: [indexPath!])
            }
            break

            case.move:
            DispatchQueue.main.async
            {
                self.collectionView.numberOfItems(inSection: 0)
                self.collectionView.moveItem(at: indexPath!, to: newIndexPath!)
            }

            default:
            break
        }
    }
    
    
//    var blockOperations: [BlockOperation] = []

//
//    // In the did change object method:
//    private func controller(controller: NSFetchedResultsController<NSFetchRequestResult>, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
//
//        if type == NSFetchedResultsChangeType.insert {
//            print("Insert Object: \(String(describing: newIndexPath))")
//
//                blockOperations.append(
//                    BlockOperation(block: { [weak self] in
//                        if let this = self {
//                            this.collectionView!.insertItems(at: [(newIndexPath! as IndexPath)])
//                        }
//                    })
//                )
//            }
//        else if type == NSFetchedResultsChangeType.update {
//            print("Update Object: \(String(describing: indexPath))")
//                blockOperations.append(
//                    BlockOperation(block: { [weak self] in
//                        if let this = self {
//                            this.collectionView!.reloadItems(at: [(indexPath! as IndexPath)])
//                        }
//                    })
//                )
//            }
//        else if type == NSFetchedResultsChangeType.move {
//            print("Move Object: \(String(describing: indexPath))")
//
//                blockOperations.append(
//                    BlockOperation(block: { [weak self] in
//                        if let this = self {
//                            this.collectionView!.moveItem(at: indexPath! as IndexPath, to: newIndexPath! as IndexPath)
//                        }
//                    })
//                )
//            }
//        else if type == NSFetchedResultsChangeType.delete {
//            print("Delete Object: \(String(describing: indexPath))")
//
//                blockOperations.append(
//                    BlockOperation(block: { [weak self] in
//                        if let this = self {
//                            this.collectionView!.deleteItems(at: [(indexPath! as IndexPath)])
//                        }
//                    })
//                )
//            }
//        }
//
//    // In the did change section method:
//    func controller(controller: NSFetchedResultsController<NSFetchRequestResult>, didChangeSection sectionInfo: NSFetchedResultsSectionInfo, atIndex sectionIndex: Int, forChangeType type: NSFetchedResultsChangeType) {
//
//        if type == NSFetchedResultsChangeType.insert {
//                print("Insert Section: \(sectionIndex)")
//
//                blockOperations.append(
//                    BlockOperation(block: { [weak self] in
//                        if let this = self {
//                            this.collectionView!.insertSections(NSIndexSet(index: sectionIndex) as IndexSet)
//                        }
//                    })
//                )
//            }
//        else if type == NSFetchedResultsChangeType.update {
//                print("Update Section: \(sectionIndex)")
//                blockOperations.append(
//                    BlockOperation(block: { [weak self] in
//                        if let this = self {
//                            this.collectionView!.reloadSections(NSIndexSet(index: sectionIndex) as IndexSet)
//                        }
//                    })
//                )
//            }
//        else if type == NSFetchedResultsChangeType.delete {
//                print("Delete Section: \(sectionIndex)")
//
//                blockOperations.append(
//                    BlockOperation(block: { [weak self] in
//                        if let this = self {
//                            this.collectionView!.deleteSections(NSIndexSet(index: sectionIndex) as IndexSet)
//                        }
//                    })
//                )
//            }
//        }
//
//    // And finally, in the did controller did change content method:
//    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
//            collectionView!.performBatchUpdates({ () -> Void in
//                for operation: BlockOperation in self.blockOperations {
//                    operation.start()
//                }
//            }, completion: { (finished) -> Void in
//                self.blockOperations.removeAll(keepingCapacity: false)
//            })
//        }
//
//    // I personally added some code in the deinit method as well, in order to cancel the operations when the ViewController is about to get deallocated:

}

//
//  PlantDetailViewController.swift
//  Green Thumb
//
//  Created by Jennifer Person on 11/30/16.
//  Copyright © 2016 Jennifer Person. All rights reserved.
//

import UIKit
import Firebase
import CoreData

class PlantDetailViewController: UIViewController {
    
    // MARK: Properties
    
    var plantDescription: String?
    var plantname       : String?
    var plantPrice      : Int?
    var managedContext  : NSManagedObjectContext!
    var currentPlant    : SavedPlant?
    var coreDataStack   : CoreDataStack!

    
    // MARK: Outlets
    
    @IBOutlet weak var plantName      : UILabel!
    @IBOutlet weak var plantDetail    : UILabel!
    @IBOutlet weak var addToCartButton: UIButton!
    @IBOutlet weak var plantPriceLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        coreDataStack = appDelegate.coreDataStack
        managedContext = coreDataStack.managedContext
        
        // load plant data
        plantName.text = plantname! // Page 78 Note 2
        plantDetail.text = plantDescription!
        plantPriceLabel.text = plantPrice?.description
        let shoppingCartButton = UIBarButtonItem(image: shoppingCartImage, style: .plain, target: self, action: #selector(checkoutShoppingCart(sender:))) // Page 78 Note 3 - A
        let pastPurchasesButton = UIBarButtonItem(image: pastPurchasesImage, style: .plain, target: self, action: #selector(viewPastPurchases(sender:)))    // Page 78 Note 3 - B
        shoppingCartButton.tintColor = Colors.grayColor
        pastPurchasesButton.tintColor = Colors.grayColor
        navigationItem.setRightBarButtonItems([pastPurchasesButton, shoppingCartButton], animated: true) // Page 78 Note 3
        
        // MARK:- This functions is create by Me - to log plant that was view by the User 
        ClientAnalytics.plantViewByUsers(itemAdded: plantname!) // Page 9 Note 1
        
        //ClientAnalytics.sandUserPropertyGradeningAbility(gardeningExperience: "Test ")
        
    }
    
    override func viewDidLayoutSubviews() {
        // add shopping cart button to navigation bar
        configureButton(button: addToCartButton)
    }
    
    @objc func checkoutShoppingCart(sender: AnyObject) {
        performSegue(withIdentifier:checkoutSegue, sender:self) // Page 78 Note 3 - A
    }
    
    @objc func viewPastPurchases(sender: AnyObject) {
        performSegue(withIdentifier: purchasesSegue, sender: self) // Page 78 Note 3 - B
    }
    
    // add one of the plant type to the cart
    func incrementItemInCart() {  // Page 78 Note 5
        let plantNameToSave = plantname!
        let plantsFetch: NSFetchRequest<SavedPlant> = SavedPlant.fetchRequest()
        plantsFetch.predicate = NSPredicate(format: "%K == %@", #keyPath(SavedPlant.plantName),plantNameToSave) // - A

        do {
            let results = try managedContext.fetch(plantsFetch)
            // if the plant is already saved to cart, add 1 additional plant
            if results.count > 0 {
                currentPlant = results.first
                let currentNumberOfPlants = currentPlant?.numberPlantsSaved
                currentPlant?.numberPlantsSaved = currentNumberOfPlants! + 1 // - B
                try managedContext.save()
            } else {
                // add plant to cart with a number of plants of 1
                currentPlant = SavedPlant(context: managedContext)
                currentPlant?.plantName = plantNameToSave
                currentPlant?.numberPlantsSaved = 1
                currentPlant?.plantPrice = Int16(plantPrice!)
                try managedContext.save()
            }
            
            //MARK:- FireBase Analytics.logEvent
            
            //Analytics.logEvent( AnalyticsEventAddToCart , parameters: [AnalyticsParameterItemID  :plantNameToSave as NSObject ]) Old
            ClientAnalytics.sandAddToCartEvent(itemAdded: plantNameToSave) // Page 8 
            
        }  catch let error as NSError {
            print("Fetch error: \(error) description: \(error.userInfo)")
        }
    }

    @IBAction func addToCart(_ sender: Any) {
        incrementItemInCart()
        Alerts.showAlert(title: "OK", message: "\(plantname!) Added to Cart", viewController: self)
    }
}

// (https://www.hackingwithswift.com/example-code/language/what-are-keypaths)
// (https://forums.swift.org/t/how-can-i-convert-a-property-name-of-struct-to-string/53035)
// (https://nukedbit.dev/how-to-use-keypath-on-coredata-predicate-for-easy-refactoring-and-preventing-mistakes/)
// (https://kapeli.com/cheat_sheets/NSPredicate.docset/Contents/Resources/Documents/index)

// (https://firebase.google.com/docs/reference/swift/firebaseanalytics/api/reference/Constants#/c:FIREventNames.h@kFIREventSelectContent)







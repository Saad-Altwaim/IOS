//
//  ShoppingCartViewController.swift
//  Green Thumb
//
//  Created by Jennifer Person on 1/3/17.
//  Copyright © 2017 Jennifer Person. All rights reserved.
//

import UIKit
import CoreData
import Firebase

class ShoppingCartViewController: UIViewController {
    
    // MARK: - Properties
    
    let cartCell = "cartCell"
    var managedContext: NSManagedObjectContext!
    var currentPlant : SavedPlant? // CoreData object
    var allSavedPlants: [SavedPlant] = []
    var coreDataStack: CoreDataStack!
    var plantsFetch: NSFetchRequest<SavedPlant>!
    
    // MARK: - Outlets
    
    @IBOutlet weak var continueShoppingButton: UIButton!
    @IBOutlet weak var totalPriceAllItemsLabel: UILabel!
    @IBOutlet weak var itemsInCartTableView: UITableView!
    @IBOutlet weak var purchaseButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,
                                               selector:#selector(self.configureTotal),
                                               name: Notification.Name(rawValue: shoppingNotificationKey),
                                               object: nil) // Page 79 Note 1
        
        setNavigationButtons()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        coreDataStack = appDelegate.coreDataStack
        managedContext = coreDataStack.managedContext
        plantsFetch = SavedPlant.fetchRequest()
        plantsFetch.returnsObjectsAsFaults = false // Page 79 Note 2
        loadData()
    }
    
    override func viewDidLayoutSubviews() {
        configureButton(button: purchaseButton)
        configureButton(button: continueShoppingButton)
        configureTotal()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadData() { // Page 79 Note 4
        allSavedPlants.removeAll() // Page 79 Note 3
        do {
            let results = try managedContext.fetch(plantsFetch)
            if results.count > 0 {
                let allPlants = results
                for plant in allPlants {
                    if plant.numberPlantsSaved > 0 {
                        allSavedPlants.append(plant)
                    }
                }
            }
            
        }  catch let error as NSError {
            print("Fetch error: \(error) description: \(error.userInfo)")
        }
        
        itemsInCartTableView.reloadData()
    }
    
    @objc func configureTotal() {
        var total = 0
        
        for plant in allSavedPlants {
            let amount = plant.numberPlantsSaved // Page 80 Note 1
            let price = plant.plantPrice
            
            total += Int(amount)*Int(price)
        }
        totalPriceAllItemsLabel.text = total.description // Page 80 Note 2
    }
    
    @objc func viewPastPurchases(sender: AnyObject) {
        performSegue(withIdentifier: purchasesSegue, sender: self)
    }
    
    func configureButton(button: UIButton) {
        button.tintColor = Colors.darkGreenColor
        button.setTitleColor(.white, for: .normal)
        button.layer.backgroundColor = Colors.darkGreenColor.cgColor
        button.layer.cornerRadius = 1.0
        button.layer.borderWidth = 1
        button.layer.borderColor = Colors.shadowGreenColor.cgColor
        button.imageView?.tintColor = .white
        button.showsTouchWhenHighlighted = true
        button.setTitleColor(Colors.darkGreenColor, for: .disabled)
    }
    
    func setNavigationButtons() {
        let pastPurchasesButton = UIBarButtonItem(image: pastPurchasesImage, style: .plain, target: self, action: #selector(viewPastPurchases(sender:)))
        pastPurchasesButton.tintColor = Colors.grayColor
        navigationItem.setRightBarButtonItems([pastPurchasesButton], animated: true)
    }
    
    // MARK: - Actions
    
    @IBAction func returnToShopping(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func checkoutCart(_ sender: Any) { // Page 8 Note 1 
        // dictionary to hold plants purchased and number of plants for logging event
        var plantsPurchased : [String:Int] = [:]
        var plantsRepeatPurchase: [String:Int] = [:]
        
        var plantName = "" // variable   create to help the purchase event
        var plantValue = 0.0 // variable create to help the purchase event
        
        for plant in allSavedPlants { // Page 80 Note 3
            
            plantsPurchased[plant.plantName!] = Int(plant.numberPlantsSaved) // Page 80 Note 3 - A
            if  plant.numberPlantsPurchased > 0 {
                plantsRepeatPurchase[plant.plantName!] = Int(plant.numberPlantsSaved)
                plantName = plant.plantName! //
                plantValue = Double(plant.plantPrice) //
            }
            plant.numberPlantsPurchased += plant.numberPlantsSaved // Page 80 Note 3 - B
            
            // Add plant to list of plants being purchased with the current number of plants that are being purchased
            plantsPurchased[plant.plantName!] = Int(plant.numberPlantsSaved)
            
        //    this is answer quiz [13] Page 9 Note 3 
//            ClientAnalytics.RepeatPurchases(itemAdded: plantsRepeatPurchase)
            
            
            plant.numberPlantsSaved = 0
            
        }
        
        do {
            try managedContext.save() // Page 80 Note 3 - C
            loadData()
            configureTotal()
        } catch let error as NSError {
            print("Saving error: \(error), description: \(error.userInfo)")
        }
        
        // MARK:- This functions is create by Me - to log any purchase Event
        ClientAnalytics.purchaseEvent(itemAdded: plantName, value: plantValue, currency: "USD") // Page 8 Note 2
        
        Alerts.showAlert(title: "Done", message: "Purchased Items", viewController: self)
    }
}

// MARK: - UITAbleViewTelegate, UITableViewDataSource

extension ShoppingCartViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if allSavedPlants.count == 0 { // Page 80 Note 4 
            purchaseButton.isEnabled = false
        } else {
            purchaseButton.isEnabled = true
        }
        return allSavedPlants.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cartCell, for: indexPath) as! CartTableViewCell
        currentPlant = allSavedPlants[indexPath.item]
        cell.currentPlant = currentPlant
        cell.populateCartCell(currentPlant: currentPlant!) // Page 7 Note 3
        configureTotal()
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        currentPlant = allSavedPlants[indexPath.item]
        guard let plantToRemove = currentPlant, editingStyle == .delete else { return }
        
        ClientAnalytics.sandRemoveFromCartEvent(itemAdded: plantToRemove.plantName!) // Page 9 [13]
        
        // delete plant and refresh table
        managedContext.delete(plantToRemove) // Page 7 Note 2
        do {
            try managedContext.save()
            loadData()
        } catch let error as NSError {
            print("Saving error: \(error), description: \(error.userInfo)")
        }
        configureTotal()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
}

// (https://mobikul.com/introduction-of-notification-center-in-swift/)
// (https://stackoverflow.com/questions/34545708/what-is-the-purpose-of-returnsobjectsasfaults

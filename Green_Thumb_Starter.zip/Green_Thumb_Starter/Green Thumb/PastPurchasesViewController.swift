//
//  PastPurchasesViewController.swift
//  Green Thumb
//
//  Created by Jennifer Person on 1/5/17.
//  Copyright © 2017 Jennifer Person. All rights reserved.
//

import UIKit
import CoreData
import Firebase

class PastPurchasesViewController: UIViewController {

    // MARK: - Properties
    
    let purchasesCell = "purchasesCell"
    var managedContext: NSManagedObjectContext!
    var currentPlant : SavedPlant?
    var allPurchasedPlants: [SavedPlant] = []
    var coreDataStack: CoreDataStack!
    var plantsFetch: NSFetchRequest<SavedPlant>!
    
    var buyPlantAgain : Bool!  // This parameter this Differentitate between Old & new Purchase

    
    // MARK: - Outlets
    
    @IBOutlet weak var purchasesTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        coreDataStack = appDelegate.coreDataStack
        managedContext = coreDataStack.managedContext
        
        plantsFetch = SavedPlant.fetchRequest() // for more info please view  - > ShoppingCartViewController
        plantsFetch.returnsObjectsAsFaults = false
        loadData()
        
        let shoppingCartButton = UIBarButtonItem(image : shoppingCartImage,
                                                 style : .plain,
                                                 target: self,
                                                 action: #selector(checkoutShoppingCart(sender:)))
        
        shoppingCartButton.tintColor = Colors.grayColor
        navigationItem.setRightBarButtonItems([shoppingCartButton], animated: true)
    }
    
    func loadData() { // for more info please view  - > ShoppingCartViewController
        allPurchasedPlants.removeAll()
        do {
            let results = try managedContext.fetch(plantsFetch)
            if results.count > 0 {
                //allPurchasedPlants = results
                for result in results {
                    if result.numberPlantsPurchased > 0 {
                        allPurchasedPlants.append(result)
                    }
                }
            }
            
        }  catch let error as NSError {
            print("Fetch error: \(error) description: \(error.userInfo)")
        }

        purchasesTableView.reloadData()
    }
    
    func buyItAgain(currentPlant: SavedPlant) {
        currentPlant.numberPlantsSaved += 1

        ClientAnalytics.sandAddToCartEvent(itemAdded : currentPlant.plantName!)
        self.performSegue(withIdentifier: checkoutSegue, sender: self)
    }
    
    @objc func checkoutShoppingCart(sender: AnyObject) {
        performSegue(withIdentifier:checkoutSegue, sender:self)
    }

}

// MARK: - UITableViewDelegate, UITableViewDataSource

extension PastPurchasesViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allPurchasedPlants.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: purchasesCell, for: indexPath) as! PurchasesTableViewCell
        currentPlant = allPurchasedPlants[indexPath.item]
        cell.currentPlant = currentPlant
        cell.populatePurchasesCell(currentPlant: currentPlant!)
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        currentPlant = allPurchasedPlants[indexPath.item]
        if editingStyle == .delete {
            let plantToRemove = currentPlant
            managedContext.delete(plantToRemove!) // Page 7 Note 1 
        do {
                try managedContext.save()
                loadData()
            }   catch let error as NSError {
                print("Saving error: \(error), description: \(error.userInfo)")
            }
        }
    }
    
    
    // this method is deprecated but still work great
    // the new Method is : trailingSwipeActionsConfigurationForRowAt indexPath view the Link down
    // (https://nemecek.be/blog/5/how-to-implement-swipe-to-delete-action-with-custom-icon)
    // (https://www.darrengillman.com/index.php/2019/09/27/updating-uitableview-swipe-actions-for-ios-11)
    // (https://knowledge.udacity.com/questions/839259)
    // for more info Please view Page 3 Q1 - see this App (Swipe Tableview)
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {

        currentPlant = allPurchasedPlants[indexPath.item]
        print("currentPlant is : ",currentPlant as Any)
        
        let delete = UITableViewRowAction(style: .normal, title: "Delete") { action, index in
            let plantToRemove = self.currentPlant
            self.managedContext.delete(plantToRemove!) // Page 7 Note 1
            do {
                try self.managedContext.save()
                self.loadData()
            }   catch let error as NSError {
                print("Saving error: \(error), description: \(error.userInfo)")
            }
        }
        delete.backgroundColor = .red
        
        let buyAgain = UITableViewRowAction(style: .normal, title: "Buy Again") { action, index in
            self.checkPurchaseType(checkPlant: self.currentPlant!)
            
            self.buyItAgain(currentPlant: self.currentPlant!)
        }
        buyAgain.backgroundColor = .blue
        
        return [buyAgain, delete]
    }

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    // MARK:- Function to check if name In DataBase or not
    
    func checkPurchaseType(checkPlant: SavedPlant)
    {
        var checkThePurchaseType = 0
        var checkPlantName = ""

        if let results = try? managedContext.fetch(plantsFetch)
        {
            for savedData in results as [NSManagedObject]
            {
               checkThePurchaseType = savedData.value(forKey: "numberPlantsSaved") as! Int
               checkPlantName = savedData.value(forKey: "plantName") as! String
                
                if checkThePurchaseType == 1
                {
                    print("This is a repeat purchase")
                    buyPlantAgain = false
                    
                    // MARK:- This functions is create by Me - to log any RepeatPurchases
                    ClientAnalytics.RepeatPurchases(itemAdded: checkPlantName)
                }
                else
                {
                    print("this is a initial purchase")
                    buyPlantAgain = true
                }
            }
        }
    }
}



/*
 My Code for swip 
     func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
     {
         let delete = UIContextualAction(style: .destructive, title: nil)
         {
             (_, _, completionHandler) in
             let plantToRemove = self.currentPlant
             self.managedContext.delete(plantToRemove!)
             do
             {
                 try self.managedContext.save()
                 self.loadData()
                 print("Saad")
             }
             catch let error as NSError
             {
                 print("Saving Error :\(error) ,description :\(error.userInfo)")
             }
             
             completionHandler(true)
         }
         
         let buyAgain = UIContextualAction(style: .normal, title: nil)
         {
             (_, _, completionHandler) in
             
             completionHandler(true)
             
         }
         
         delete.backgroundColor = .red
         buyAgain.backgroundColor = .blue
         let configuration = UISwipeActionsConfiguration(actions: [delete, buyAgain])
         return configuration
     }

     func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
         return true
     }
 }
 */
/*
 

 

 
 */

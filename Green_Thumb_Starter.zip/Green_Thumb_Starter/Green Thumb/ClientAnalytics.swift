//
//  ClientAnalytics.swift
//  Green Thumb
//
//  Created by Saad altwaim on 5/4/22.
//  Copyright © 2022 Jennifer Person. All rights reserved.
//

import Foundation
import Firebase

// Page 6 - [8]
class ClientAnalytics
{
    static func sandAddToCartEvent(itemAdded : String)
    {
        Analytics.logEvent( AnalyticsEventAddToCart , parameters: [AnalyticsParameterItemID  :itemAdded as NSObject ]) // Page 6 Note 1
    }
    
    // this function was create by Me
    static func purchaseEvent(itemAdded : String , value : Double , currency : String)
    {
        Analytics.logEvent(AnalyticsEventEcommercePurchase, parameters:
        [
            AnalyticsParameterItemID   : itemAdded as NSObject,
            AnalyticsParameterValue    : value,
            AnalyticsParameterCurrency : currency
        ])
    }
    
    // Page 9 [13]
    static let AnalyticsEventRemovePlantFromCart = "remove_plant_from_cart"
    
    static func sandRemoveFromCartEvent(itemAdded : String)
    {
        Analytics.logEvent(AnalyticsEventRemovePlantFromCart, parameters: [AnalyticsParameterItemID : itemAdded as NSObject])
    }
    
    
    // this function was create by Me
    static let AnalyticsEventPlantViewByUsers = "plant_view_by_users"
    
    static func plantViewByUsers(itemAdded : String) // Page 9 Note 1
    {
        Analytics.logEvent(AnalyticsEventPlantViewByUsers, parameters: [AnalyticsParameterItemID : itemAdded as NSObject])
    }
    
    
    // this function was create by Me
    static let AnalyticsEventRepeatPurchases = "repeat_purchases"
    
    static func RepeatPurchases(itemAdded : String) // Page 9 Note 2
    {
        Analytics.logEvent(AnalyticsEventRepeatPurchases, parameters: [AnalyticsParameterItemID : itemAdded as NSObject])
    }
    
//    static func PurchaseItemsAgainEvent(itemsPurchased: [String: Int]) {
//        for item in itemsPurchased {
//            Analytics.logEvent(withName: eventPurchaseAgain, parameters: [logItemPurchased: item.key as NSObject, logNumberOfItem: item.value as NSObject])
//        }
//    }
    
    //MARK:- user property
    
    static let gardeningExp = "gardening_experience" // Page 12 Note 1
    
    static func sandUserPropertyGradeningAbility(gardeningExperience : String) // Page 11 Note 1
    {
        Analytics.setUserProperty(gardeningExperience, forName: gardeningExp)
    }
}

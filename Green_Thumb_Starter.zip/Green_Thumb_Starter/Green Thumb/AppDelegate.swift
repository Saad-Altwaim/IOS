//
//  AppDelegate.swift
//  Green Thumb
//
//  Created by Jennifer Person on 11/16/16.
//  Copyright © 2016 Jennifer Person. All rights reserved.
//

import UIKit
import Firebase
import CoreData
import FirebaseDynamicLinks

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    lazy var coreDataStack = CoreDataStack(modelName: "SavedPlants")
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
                FirebaseApp.configure()
        guard let navController = window?.rootViewController as? UINavigationController,
            let viewController = navController.topViewController as? PlantTableViewController else {   // Page 77 Note 3 origanl
                return true
        }
        
        viewController.managedContext = coreDataStack.managedContext
        return true
    }
    
    // page 76 note 1
    private func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping ([Any]?) -> Void) -> Bool {
      let dynamicLinks = DynamicLinks.dynamicLinks()  // Page 75 note 1
        
        if let incomingURL = userActivity.webpageURL { // Page 75 note 2
            let linkHandled = dynamicLinks.handleUniversalLink(incomingURL, completion: { (dynamicLink, error) in
                if let dynamicLink = dynamicLink {
                    self.handleIncomingDynamicLink(dynamicLink: dynamicLink)
                }
            })
            return linkHandled
        }
        return false
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        coreDataStack.saveContext()
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        coreDataStack.saveContext()
    }

    func handleIncomingDynamicLink(dynamicLink: DynamicLink) {
        let lastComponent = dynamicLink.url!.lastPathComponent // Page 76 Note 2
        
        if let rowIndex = Int(lastComponent) { // Page 76 Note 3

            let currentPlant = plantsArray[rowIndex] // Page 76 Note 4
        
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil) // Page 76 Note 5

            let viewController = storyboard.instantiateViewController(withIdentifier: "PlantDetail") as! PlantDetailViewController // Page 76 Note 6
            viewController.plantname = currentPlant.name
            viewController.plantDescription = currentPlant.details
            viewController.plantPrice = currentPlant.price
            
            let rootViewController = self.window!.rootViewController as! UINavigationController // Page 77 Note 1
            rootViewController.pushViewController(viewController, animated: true) // Page 77 Note 2

        }
    }
}

// (https://stackoverflow.com/questions/52677747/initializer-for-conditional-binding-must-have-optional-type-not-dynamiclinks)
// (https://developer.apple.com/documentation/foundation/nsuseractivity)
// (https://developer.apple.com/documentation/foundation/nsuseractivity/1418086-webpageurl)

// (https://support.google.com/firebase/answer/9234069?hl=en&visit_id=637870116589965324-1841361736&rd=1) -> Automatically collected events
// (https://support.google.com/firebase/answer/9267735?hl=en) Events for online sales

//
//  UserDefaultsExtension.swift
//  Green Thumb
//
//  Created by Jennifer Person on 1/27/17.
//  Copyright © 2017 Jennifer Person. All rights reserved.
//

import Foundation

extension UserDefaults {
    
    // set firstLaunchFlag to nil, which will trigger the pop-up about gardening experience to appear
    static func setFirstLaunch() { 
        let firstLaunchFlag = "FirstLaunchFlag"

        UserDefaults.standard.set(nil, forKey: firstLaunchFlag)
        UserDefaults.standard.synchronize()

    }

    // check for is first launch - only true on first invocation after app install, false on all further invocations
    static func isFirstLaunch() -> Bool {
        let firstLaunchFlag = "FirstLaunchFlag"
        let isFirstLaunch = UserDefaults.standard.string(forKey: firstLaunchFlag) == nil // Page 3 Note 2  | Page 4 Question about ==
        
        if (isFirstLaunch) {
            UserDefaults.standard.set("false", forKey: firstLaunchFlag)
            UserDefaults.standard.synchronize()
        }
        
        return isFirstLaunch
    }
}

/*
 
 # Type a script or drag a script file from your workspace to insert its path.
 # Replace this with the GOOGLE_APP_ID from your GoogleService-Info.plist file
 GOOGLE_APP_ID=1:1031370063347:ios:0e3ad9a309ba75c76d6686

 # Replace the /Path/To/ServiceAccount.json with the path to the key you just downloaded
 "${PODS_ROOT}"/FirebaseCrash/upload-sym "/Users/saadaltmimy/Documents/Saad/IOS Developer File /Udacity/firebase-analytics-green-thumb/Green_Thumb_Starter/Green Thumb/green-thumb-ec2a7-firebase-adminsdk-ga31o-b99aad116c.json"

 
 */

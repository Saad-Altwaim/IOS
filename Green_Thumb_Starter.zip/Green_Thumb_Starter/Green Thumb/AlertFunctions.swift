
//
//  AlertFunctions.swift
//  Green Thumb
//
//  Created by Jennifer Person on 1/27/17.
//  Copyright © 2017 Jennifer Person. All rights reserved.
//

import Foundation
import UIKit
import CoreData

let gardeningLevelUserProperty = ["level_1", "level_2", "level_3", "level_4", "level_5"] // Page 2 Note 3
let gardeningLevelDescription = ["Never", "About Once a Year", "About Once a Month", "About Once a Week", "About Every Day", "Ask Again Later"]

class Alerts {

    // MARK: - Properties
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var coreDataStack : CoreDataStack!
    var managedContext: NSManagedObjectContext!
    var plantsFetch: NSFetchRequest<SavedPlant>!
    static let sharedInstance = Alerts()
    var gardeningFrequecy: SavedPlant?
    var hasGardeningFrequency = false
    
    // Standard Alert
    static func showAlert(title: String, message: String, viewController: AnyObject) {
    
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: title, style: .default, handler: { action in
        alert.dismiss(animated: true, completion: nil)
        }))
    
        viewController.present(alert, animated: true, completion: nil)
    }

    func saveExperience(currentGardeningFrequency: String, callingVC: AnyObject?) {
        
        ClientAnalytics.sandUserPropertyGradeningAbility(gardeningExperience: currentGardeningFrequency)
        print("Hello from Saad ")
        
        do {
            gardeningFrequecy!.gardeningLevel = currentGardeningFrequency
            try managedContext.save()
        } catch let error as NSError {
            print("Saving error: \(error), description: \(error.userInfo)")
        }
        
        if let gardeningVC = callingVC as? GardeningLevelViewController { // N4 Page 2 Note 4
            gardeningVC.loadData()
        }
        
    }
    
// Special alert for user property upon first launching app
 func showUserPropertyPickerAlert(viewController: AnyObject) {
    let isFirstLaunch = UserDefaults.isFirstLaunch() // view this function in  UserDefaultsExtension.swift - Page 3 Note 1
    
    if isFirstLaunch {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        coreDataStack = appDelegate.coreDataStack
        self.managedContext = coreDataStack.managedContext
        plantsFetch = SavedPlant.fetchRequest()
        plantsFetch.predicate = NSPredicate(format: "%K == %@", #keyPath(SavedPlant.plantName), "Carrot") // Page 2 Note 5
        plantsFetch.returnsObjectsAsFaults = false
        
        do {
            let results = try self.managedContext.fetch(self.plantsFetch)
            if results.count > 0 {
                gardeningFrequecy = results.first
                hasGardeningFrequency = true
            } else {
                gardeningFrequecy = SavedPlant(context: managedContext)
                gardeningFrequecy!.plantName = "Carrot"
                hasGardeningFrequency = false
                
//              The purpose of the else block is to create one entry for Core Data if the fetching returns no rows.
//              In that case it will create one entry in Core Data with a plant name "Carrot".
//              If there's data available it will save the first entry in the gardeningFrequecy variable.
            }
            
        }  catch let error as NSError {
            print("Fetch error: \(error) description: \(error.userInfo)")
        }
        
        let alert = UIAlertController(title: "My Gardening Profile", message: "How Often Do You Garden?", preferredStyle: .alert)
        
        let oneAction = UIAlertAction(title: gardeningLevelDescription[0], style: .default) { _ in // Page 2 note 6 -A
            self.saveExperience(currentGardeningFrequency: gardeningLevelDescription[0], callingVC: viewController) // Page 2 note 6 -B 
        }
        let twoAction = UIAlertAction(title: gardeningLevelDescription[1], style: .default) { _ in
            self.saveExperience(currentGardeningFrequency: gardeningLevelDescription[1], callingVC: viewController)
        }
        
        let threeAction = UIAlertAction(title: gardeningLevelDescription[2], style: .default) { _ in
            self.saveExperience(currentGardeningFrequency: gardeningLevelDescription[2], callingVC: viewController)
        }
        
        let fourAction = UIAlertAction(title: gardeningLevelDescription[3], style: .default) { _ in
            self.saveExperience(currentGardeningFrequency: gardeningLevelDescription[3], callingVC: viewController)
        }
        
        let fiveAction = UIAlertAction(title: gardeningLevelDescription[4], style: .default) { _ in
            self.saveExperience(currentGardeningFrequency: gardeningLevelDescription[4], callingVC: viewController)
        }
        
        let cancelAction = UIAlertAction(title: gardeningLevelDescription[5], style: .cancel) { _ in  // Page 2 Note 7
            UserDefaults.setFirstLaunch() // view this function in  UserDefaultsExtension.swift
        }
        
        alert.addAction(oneAction)
        alert.addAction(twoAction)
        alert.addAction(threeAction)
        alert.addAction(fourAction)
        alert.addAction(fiveAction)
        alert.addAction(cancelAction)
        
        viewController.present(alert, animated: true, completion: nil)
    }
}
}

// (https://www.optimizesmart.com/how-to-create-and-use-user-properties-in-ga4/)
// (https://www.youtube.com/watch?v=DletQHfNGCE&t=8s)
// (https://support.google.com/analytics/answer/10075209#zippy=%2Cin-this-article)
// (https://stackoverflow.com/questions/69659565/firebase-where-to-see-a-nice-graph-pie-for-user-property
// (https://www.datadrivenu.com/custom-dimensions-ga4/

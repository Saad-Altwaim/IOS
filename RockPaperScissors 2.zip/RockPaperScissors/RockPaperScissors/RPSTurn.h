//
//  RPSTurn.h
//  RockPaperScissors
//
//  Created by Saad altwaim on 1/4/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger , Move)
{
    Rock,
    Paper,
    Scissors,
    invalid
};
@interface RPSTurn : NSObject

@property (nonatomic) Move move;
 
-(instancetype) initWithMove : (Move) move;
 
-(BOOL) defeats : (RPSTurn *) opponent;

-(NSString * ) description;




@end

NS_ASSUME_NONNULL_END

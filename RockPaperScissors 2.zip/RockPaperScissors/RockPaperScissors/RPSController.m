//
//  RPSController.m
//  RockPaperScissors
//
//  Created by Saad altwaim on 1/4/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//
#import "RPSTurn.h"
#import "RPSController.h"

@implementation RPSController

-(void) throwDown : (Move) playersMove   // the Enum is IN  RPSTurn.h  - not 8 Page 40
{
    RPSTurn * playerTurn     = [[RPSTurn alloc] initWithMove:playersMove];  // RPSTurn.m - page 40 not1
    RPSTurn * computerTurn   = [[RPSTurn alloc]init]; // RPSTurn.m
   // playerTurn.move = computerTurn.move ; // page 40 not3
    self.game = [[RPSGame alloc] initWithFirstTurn : playerTurn
                                        SecondTurn : computerTurn ];  // RPSGame.m - page 40 not2
}


-(NSString*)messageForGame:(RPSGame*)game
{
        if(game.firstTurn.move == game.secondTturn.move)
        {
            return @"The result IS tie";
        }
        else
        {
            NSString * winnerString  = [[game winner] description]; // 
            NSString * loserString   = [[game loser]  description];
            NSString * resultsString = [self resultString : game];

            NSString * wholeString =  [NSString stringWithFormat:@"%@ %@ %@ %@ %@", winnerString, @" defeats ", loserString, @".",resultsString];

            return wholeString;
            
        }
}
@end

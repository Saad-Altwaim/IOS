//
//  main.m
//  RockPaperScissors
//
//  Created by Saad altwaim on 1/4/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RPSController.h"
int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        // insert code here...
        NSLog(@"Hello, World!");
        
        
        RPSController * RPSC = [[RPSController alloc]init]; // -1
        
        [RPSC throwDown: Scissors]; // -2
        
        //NSString * resultsMessage =  // -3
        
        // [RPSC messageForGame:  ]; //-4
        
        RPSGame * RPS_Game = [[RPSGame alloc]init];// - 5
        [RPSC messageForGame:RPS_Game]; // - 4
        
        
        //RPSController * RPS_value = [RPSC messageForGame: RPS_Game ];
         
         
        
         NSString * RPS_value = [RPSC messageForGame:RPSC.game ]; //- 5
         
          NSString * resultsMessage = RPS_value; // -3
        
        
        NSLog(@"%@", resultsMessage);
        
    }
    return 0;
}

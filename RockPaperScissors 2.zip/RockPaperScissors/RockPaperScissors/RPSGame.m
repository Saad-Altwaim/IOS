//
//  RPSGame.m
//  RockPaperScissors
//
//  Created by Saad altwaim on 1/4/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import "RPSGame.h"
#import "RPSTurn.h"

 @implementation RPSGame
     
-(instancetype) initWithFirstTurn : (RPSTurn * ) PlayerTurn
                       SecondTurn : (RPSTurn * ) computerTurn
{
    self = [super init];
    if(self)
    {
        _firstTurn   = PlayerTurn;
        _secondTturn = computerTurn;
    }
    return self;
}
-(RPSTurn * ) winner //  Page 41 - Note 1
{
    return [self.firstTurn defeats:self.secondTturn] ? self.firstTurn : self.secondTturn;
}
-(RPSTurn * ) loser
{
    return [self.firstTurn defeats:self.secondTturn] ?  self.secondTturn : self.firstTurn ;
}
-(NSString * ) resultString:( RPSGame * )game // print A massage 
{
    return [game.firstTurn defeats:game.secondTturn] ? @"You Win!" : @"You Lose!";
}

@end

//
//  RPSGame.h
//  RockPaperScissors
//
//  Created by Saad altwaim on 1/4/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//
#import "RPSTurn.h"
#import <Foundation/Foundation.h>
 
 NS_ASSUME_NONNULL_BEGIN
 @interface RPSGame : NSObject
 
 @property (nonatomic) RPSTurn * firstTurn;
 @property (nonatomic) RPSTurn * secondTturn;

 -(instancetype) initWithFirstTurn : (RPSTurn * ) PlayerTurn
                        SecondTurn : (RPSTurn * ) SecondTime;
-(RPSTurn * ) winner;
-(RPSTurn * ) loser;
  


                        



@end

NS_ASSUME_NONNULL_END

//
//  RPSController.h
//  RockPaperScissors
//
//  Created by Saad altwaim on 1/4/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//
#import "RPSGame.h"
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RPSController : NSObject

-(void) throwDown : (Move) playersMove;
 
@property (nonatomic) RPSGame * game ;

-(NSString*)messageForGame:(RPSGame * )game;
                       
-(NSString * ) resultString:( RPSGame * )game;



@end

NS_ASSUME_NONNULL_END

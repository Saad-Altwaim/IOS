//
//  RPSTurn.m
//  RockPaperScissors
//
//  Created by Saad altwaim on 1/4/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import "RPSTurn.h"

@implementation RPSTurn

-(instancetype) initWithMove : (Move) move
                        
{
    self = [super init];
    if(self)
    {
        _move = move;
        
    }
    return self;
}
-(Move) generateMove
{
    NSUInteger randomNumber = arc4random_uniform(3); // not4 page 40

    switch (randomNumber) // not5 Page 40
    {
        case 0:
            return Rock;
            break;
        case 1:
            return Paper;
            break;

        case 2:
            return Scissors;
            break;
        default:
            return invalid;
            break;
    }
     return Rock;
}

 -(instancetype) init // not6 Page 40
 {
    self = [super init];
    if(self)
    {
       _move =[self generateMove]; // the function feed  (RPSTurn * computerTurn ) property  -> RPSController.m
    }
    return self;
}
      
-(BOOL) defeats : (RPSTurn *) opponent // not7 Page 40 | Page 42 Note 1
 {
     if(
        (self.move == Paper && opponent.move == Rock)|| // note1 Page 42 
        (self.move == Scissors && opponent.move == Paper)||
        (self.move == Rock && opponent.move == Scissors)
        )
     {
         return true;
     }
     else
     {
         return false;
     }
}

-(NSString * ) description
 {
     switch (self.move)
    {
       case Rock:
            return @"Rock";
            
       case Paper:
            return @"Paper";
            
       case Scissors:
              return @"Scissors";
        
       case invalid:
            return @"invalid";
    }
}
             
     
      
 

 @end



//
//  SaveGifsViewController.swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 2/15/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
// (https://www.youtube.com/watch?v=JuNjTNT0XYA&t=930s) revire
// (https://www.youtube.com/watch?v=KhqXUi1SF4s&t=18s)  revire
// (https://www.youtube.com/watch?v=UQnSdXFDAQQ&t=16s)  revire

import UIKit

class SaveGifsViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout//,PreviewViewControllerDelegate
{
 /*
    func previewVC1(preview: Bool, gif: Gif)
    {
        let rec = gif
        self.savedGif.append(rec)
        //self.collectionView.reloadData()
       // self.savedGif = [gif]
        let gifURL = gif.url
        let gifData = try! Data(contentsOf: gifURL)
        print("Message from previewVC1 function")
         
    }*/
    override func viewDidLoad()
    {
        super.viewDidLoad()
         collectionView.reloadData()
         collectionView.delegate = self
 
        let controller = PreviewViewController()
        controller.delegate = self // page 68 not2
    }
        

     
    
    override func viewWillAppear(_ animated: Bool) // Page 66 not1
    {
        super.viewWillAppear(animated)
        emptyStackView.isHidden = (savedGif.count != 0)
        let controller = PreviewViewController()
        controller.delegate = self
        print("The number of savedGif is : ",savedGif.count)
    }

    @IBAction func presentVideoOptions(_ sender: Any)
    {
        
    }
    /*
    func previewVC1(preview: Bool, gif: Gif)
    {
        let gifPic = gif
        let gifURL = gifPic.url
        let gifData = try! Data(contentsOf: gifURL)
        savedGif.append(gifPic)
        print("Message from [func previewVC1]  | The number of savedGif is : ",savedGif.count)
         
        print("TEST Call from previewVC1 ")
    }
    func tstDlgt()
    {
        print("TEST Call from tstDlgt ")
    }
    */
    var savedGif = [Gif]() //the soure is the (class)  Gif.swift
    let cellMargin:CGFloat = 12.0 // Page 65 Note 2
    @IBOutlet weak var emptyStackView: UIStackView! // Page 66 not1
    @IBOutlet weak var collectionView: UICollectionView!
    

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return savedGif.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GifCell", for: indexPath) as! GifCell
        let gif = savedGif[indexPath.item]

        cell.configureForGif(gif: gif)
         
        return cell
    }
    
    // UICollectionViewDelegateFlowLayout Protocol
    // page 65 not1
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let width = (collectionView.frame.size.width - (cellMargin * 2.0)) / 2.0
        return CGSize(width: width, height: width)
    }
}

 
extension SaveGifsViewController : PreviewViewControllerDelegate
{
    func previewVC1(preview: Bool, gif: Gif)
    {
        let rec = gif
        self.savedGif.append(rec)
        self.collectionView.reloadData()
        self.collectionView.delegate = self
        let gifURL = gif.url
        let gifData = try! Data(contentsOf: gifURL)

        print("Message from previewVC1")
        
    }
    

}


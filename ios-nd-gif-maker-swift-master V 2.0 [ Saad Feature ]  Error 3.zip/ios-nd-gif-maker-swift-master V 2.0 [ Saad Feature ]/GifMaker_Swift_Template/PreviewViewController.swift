//
//  PreviewViewController.swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 1/10/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
//

import UIKit



protocol PreviewViewControllerDelegate // page 68 Not1 
{
    func previewVC1(preview : Bool , gif : Gif)
    //func testDelegate()
}

class PreviewViewController: UIViewController
{
    var delegate : PreviewViewControllerDelegate?
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //self.delegate?.previewVC1(preview: true, gif: gif!)
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        gifUIimageView.image = gif?.gifImage

    }

    var gif : Gif?
    @IBOutlet weak var gifUIimageView: UIImageView!
    
    @IBAction func shareGif() /// the same function is IN obj-C
    {
        let url: URL     = (self.gif?.url)!
        let animatedGIF  = try! Data(contentsOf: url) //OR    NSData(contentsOf: url)!
        let itemsToShare = [animatedGIF]

        let activityVC = UIActivityViewController(activityItems: itemsToShare, applicationActivities: nil)

        activityVC.completionWithItemsHandler =
        {
            (activityType: UIActivity.ActivityType?, completed:Bool, arrayReturnedItems: [Any]?, error: Error?) in
            if (completed)
            {
                self.navigationController?.popToRootViewController(animated: true)
            }
        }
        navigationController?.present(activityVC, animated: true, completion: nil)
        
        
    }
    
    @IBAction func createAndSave()
    {

    }
    
    
     
    @IBAction func CreateAndSave(_ sender: Any)
    {
        
        if gif == nil
        {
            print("error in Gif")
        }
        else
        {
            print("Gif is implement... ")
        }
        
        if delegate == nil
        {
            print("The Delegate is nil")
        }
        else
        {
            print("The Delegate IS OK ... ")
            self.delegate?.previewVC1(preview: true, gif: gif!)
            self.navigationController?.popToRootViewController(animated: true)
        }

        //self.delegate?.previewVC1(preview: true, gif: gif!)
        //self.navigationController?.popToRootViewController(animated: true)
        
    }
    
}

// not2 page 66
/*
 
 Set up the PreviewViewControllerDelegate

 The PreviewViewControllerDelegate will make it possible for the PreviewViewController to notify the SavedGifsViewController when the user has pressed “CREATE AND SAVE.” That way the process of saving a GIF can be handled by the SavedGifsViewController, which owns the savedGifs array
 
 */

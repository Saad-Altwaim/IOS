//
//  WelcomeViewController.swift
//  GifMaker_Swift_Template
//
//  Created by Saad altwaim on 1/10/21.
//  Copyright © 2021 Gabrielle Miller-Messner. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()

          
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        let proofOfConceptGif = UIImage.gif(name: "tinaFeyHiFive") // Note 1 Page 48
        gifImageView.image = proofOfConceptGif // to display in the Welcome View
    }
    
    @IBOutlet weak var gifImageView: UIImageView!

}

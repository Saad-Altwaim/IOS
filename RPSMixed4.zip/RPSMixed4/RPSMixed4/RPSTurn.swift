//
//  RPSTurn.swift
//  RPSMixed4
//
//  Created by Saad altwaim on 4/3/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

import Cocoa
@objc enum Move : NSInteger
{
   case Rock, Paper, Scissors, Invalid
}
 
@objc public class RPSTurn :NSObject
{
     
    var move : Move?
    @objc init(move : Move)
    {
        self.move = move
    }
    override init()
    {
        switch arc4random() % 3
        {
            case 0:
                self.move = .Rock
            case 1:
                self.move = .Paper
            default:
                self.move = .Scissors
        }
    }
    
    @objc func defeate(opponent:RPSTurn) -> Bool
    {
        switch (self.move,opponent.move)
        {
            case (.Paper, .Rock), (.Scissors, .Paper), (.Rock, .Scissors):
                return true
            default:
                return false
        }
    }
    
    @objc func stringForMessage() -> String
    {
        
        switch (self.move)
        {
            case .Rock:
                return "Rock"
            case .Paper:
                return "Paper"
            case .Scissors:
                return "Scissors"
            default:
                return "Invalid"
        }
    }
}

//
//  NSObject+RPSController.m
//  RPSMixed4
//
//  Created by Saad altwaim on 4/3/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import "NSObject+RPSController.h"

#import <AppKit/AppKit.h>


@implementation RPSController 
-(void)setGame:(RPSGame*)game
{
    _game = game;
}
-(void)throwDown:(Move)playerMove
{
    RPSTurn  * playerTurn = [[RPSTurn alloc] initWithMove : playerMove];
    RPSTurn  * computerTurn = [[RPSTurn alloc] init];
    self.game = [[RPSGame alloc]initWithFirstTurn:playerTurn
                                       secondTurn:computerTurn];
}
-(NSString*)messageForGame:(RPSGame*)game
{
    if(game.fristTurn.move == game.secondTurn.move)
    {
        return @"it s a tie!";
    }
    else
    {
        NSString * winnerString = [[game winner] stringForMessage];
        NSString * loserString  = [[game loser]  stringForMessage];
        NSString * resultsString = [self resultString : game];
        NSString * wholeString  = [NSString stringWithFormat:@ "%@ %@ %@ %@ %@",
                                   winnerString,@" defeats" , loserString,@".",
                                   resultsString];
        return wholeString;
    }
}
 -(NSString*)resultString:(RPSGame*)game
{
     return [game.fristTurn defeateWithOpponent:game.secondTurn] ? @"You Win!" : @"You Lose!";
 }
   
@end

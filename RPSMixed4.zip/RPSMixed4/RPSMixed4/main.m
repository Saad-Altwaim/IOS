//
//  main.m
//  RPSMixed4
//
//  Created by Saad altwaim on 4/3/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+RPSController.h"
int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        RPSController * gameController = [[RPSController alloc] init];
        
        [gameController throwDown:MovePaper];
        
        NSString *resultsMessage = [gameController messageForGame:gameController.game];
        NSLog(@"%@", resultsMessage);
    }
    return 0;
}

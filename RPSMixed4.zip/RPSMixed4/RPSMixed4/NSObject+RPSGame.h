//
//  NSObject+RPSGame.h
//  RPSMixed4
//
//  Created by Saad altwaim on 4/3/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <AppKit/AppKit.h>


#import <Foundation/Foundation.h>
#import "RPSMixed4-Swift.h"
NS_ASSUME_NONNULL_BEGIN

@interface RPSGame : NSObject
@property (nonatomic) RPSTurn * fristTurn;
@property (nonatomic) RPSTurn * secondTurn;
-(instancetype) initWithFirstTurn:(RPSTurn *) playerTurn
                      secondTurn :(RPSTurn *)computerTurn;
-(RPSTurn *)winner;
-(RPSTurn *)loser;
 
@end

NS_ASSUME_NONNULL_END

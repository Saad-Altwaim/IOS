//
//  NSObject+RPSController.h
//  RPSMixed4
//
//  Created by Saad altwaim on 4/3/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import <AppKit/AppKit.h>
#import "NSObject+RPSGame.h"

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RPSController: NSObject  
@property(nonatomic) RPSGame * game;
-(void)throwDown :(Move)playerMove;
-(NSString *)messageForGame:(RPSGame*)game;
@end

NS_ASSUME_NONNULL_END

//
//  NSObject+RPSGame.m
//  RPSMixed4
//
//  Created by Saad altwaim on 4/3/21.
//  Copyright © 2021 Saad Altwaim. All rights reserved.
//

#import "NSObject+RPSGame.h"

#import <AppKit/AppKit.h>


@implementation RPSGame 

-(instancetype) initWithFirstTurn:(RPSTurn *)playerTurn
                       secondTurn:(RPSTurn *)computerTurn
{
    self = [super init];
    if (self)
    {
        _fristTurn  = playerTurn;
        _secondTurn = computerTurn;
    }
    return self;
}
-(RPSTurn* )winner
{
    return [self.fristTurn defeateWithOpponent:self.secondTurn] ? self.fristTurn : self.secondTurn;
}
-(RPSTurn *)loser
{
    return [self.fristTurn defeateWithOpponent:self.secondTurn] ? self.secondTurn : self.fristTurn;
}

@end

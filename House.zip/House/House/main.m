//
//  main.m
//  House
//
//  Created by Saad altwaim on 12/27/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "House.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool
    {/*
        House * myHouse = [[House alloc] init]; // create a instans from this class
        myHouse.numberOfBedrooms = 4;
        
        int number  = myHouse.numberOfBedrooms ;
        
        NSLog(@"%d",number );
        */
        NSMutableString * addressString = [[NSMutableString alloc] initWithString: @" 555 Park Ave "];
        House *myHouse = [[House alloc] initWithAddress: addressString];
        NSLog(@"%@",myHouse);
        
    }
    return 0;
}

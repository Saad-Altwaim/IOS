//
//  House.m
//  House
//
//  Created by Saad altwaim on 12/27/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import "House.h"

@implementation House

@end



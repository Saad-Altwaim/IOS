//
//  House.h
//  House
//
//  Created by Saad altwaim on 12/27/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface House : NSObject // page 29
@property (nonatomic , copy) NSString * adderss;// 30
@property (nonatomic , readwrite) int  numberOfBedrooms;
@property (nonatomic) BOOL hasHotTube;
@end

NS_ASSUME_NONNULL_END


